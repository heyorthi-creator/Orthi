package com.example.magnifytranslate

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

/** টাইপ বা পেস্ট করা লেখা বাংলা⇄ইংরেজি অনুবাদ করার স্ক্রিন, সাথে অনুবাদের উচ্চারণ শোনার সুবিধা। */
class TextTranslateActivity : AppCompatActivity() {

    private lateinit var etInput: EditText
    private lateinit var tvResult: TextView
    private lateinit var pbLoading: ProgressBar
    private lateinit var btnTranslate: Button
    private lateinit var btnCopy: ImageButton
    private lateinit var btnSpeak: ImageButton
    private lateinit var tvLangFrom: TextView
    private lateinit var tvLangTo: TextView

    private var lastTranslated: String? = null
    private var isEnglishToBengali = true // false হলে বাংলা -> ইংরেজি
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_translate)

        etInput = findViewById(R.id.etInput)
        tvResult = findViewById(R.id.tvResult)
        pbLoading = findViewById(R.id.pbLoading)
        btnTranslate = findViewById(R.id.btnTranslate)
        btnCopy = findViewById(R.id.btnCopy)
        btnSpeak = findViewById(R.id.btnSpeak)
        tvLangFrom = findViewById(R.id.tvLangFrom)
        tvLangTo = findViewById(R.id.tvLangTo)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        btnTranslate.setOnClickListener { translate() }
        btnCopy.setOnClickListener { copyResult() }
        btnSpeak.setOnClickListener { speakResult() }
        findViewById<android.view.View>(R.id.btnSwapLang).setOnClickListener { swapLanguages() }

        textToSpeech = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }

        updateLanguageLabels()
    }

    override fun onDestroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        super.onDestroy()
    }

    private fun updateLanguageLabels() {
        tvLangFrom.text = if (isEnglishToBengali) getString(R.string.lang_english) else getString(R.string.lang_bengali)
        tvLangTo.text = if (isEnglishToBengali) getString(R.string.lang_bengali) else getString(R.string.lang_english)
        etInput.hint = if (isEnglishToBengali)
            getString(R.string.text_translate_hint) else getString(R.string.text_translate_hint_bn)
    }

    private fun swapLanguages() {
        isEnglishToBengali = !isEnglishToBengali
        updateLanguageLabels()
        // আগের ইনপুট/ফলাফল রেখে দিলে বিভ্রান্তিকর হতে পারে (ভুল ভাষায় থেকে যাবে), তাই খালি করে দিই
        etInput.text?.clear()
        tvResult.text = getString(R.string.no_text_found)
        lastTranslated = null
        btnCopy.visibility = android.view.View.GONE
        btnSpeak.visibility = android.view.View.GONE
    }

    private fun translate() {
        val input = etInput.text?.toString()?.trim().orEmpty()
        if (input.isEmpty()) {
            Toast.makeText(this, getString(R.string.empty_input_warning), Toast.LENGTH_SHORT).show()
            return
        }

        pbLoading.visibility = android.view.View.VISIBLE
        tvResult.text = getString(R.string.translating)
        btnCopy.visibility = android.view.View.GONE
        btnSpeak.visibility = android.view.View.GONE
        btnTranslate.isEnabled = false

        val sourceLang = if (isEnglishToBengali) TranslateLanguage.ENGLISH else TranslateLanguage.BENGALI
        val targetLang = if (isEnglishToBengali) TranslateLanguage.BENGALI else TranslateLanguage.ENGLISH

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(input)
                    .addOnSuccessListener { translated ->
                        pbLoading.visibility = android.view.View.GONE
                        btnTranslate.isEnabled = true
                        lastTranslated = translated
                        tvResult.text = translated
                        btnCopy.visibility = android.view.View.VISIBLE
                        btnSpeak.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "text", input, translated)
                        AnalyticsHelper.logTranslationDone(this, "text")
                    }
                    .addOnFailureListener {
                        pbLoading.visibility = android.view.View.GONE
                        btnTranslate.isEnabled = true
                        tvResult.text = getString(R.string.translate_failed)
                    }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                btnTranslate.isEnabled = true
                tvResult.text = getString(R.string.lens_download_error_hint)
            }
    }

    /** অনুবাদ করা লেখাটা (আউটপুট ভাষায়) জোরে পড়ে শোনায় -- ইংরেজি হলে ইংরেজি উচ্চারণে,
     *  বাংলা হলে বাংলা উচ্চারণে। */
    private fun speakResult() {
        val text = lastTranslated ?: return
        val tts = textToSpeech ?: return

        if (!ttsReady) {
            Toast.makeText(this, getString(R.string.tts_not_ready), Toast.LENGTH_SHORT).show()
            return
        }

        val targetLocale = if (isEnglishToBengali) Locale("bn", "BD") else Locale.US
        val result = tts.setLanguage(targetLocale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // অনেক ফোনে বাংলা ভয়েস প্যাক ডিফল্টভাবে ইনস্টল করা থাকে না
            Toast.makeText(this, getString(R.string.tts_language_unavailable), Toast.LENGTH_LONG).show()
            return
        }

        tts.stop()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "orthi_text_translate_tts")
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
