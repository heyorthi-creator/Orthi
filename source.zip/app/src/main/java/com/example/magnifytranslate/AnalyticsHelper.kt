package com.example.magnifytranslate

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Firebase Analytics-এর নিরাপদ wrapper -- google-services.json না থাকলে বা Firebase
 * ঠিকমতো সেটআপ না থাকলেও অ্যাপ যেন কখনো ক্র্যাশ না করে, তাই প্রতিটা কল try-catch-এ মোড়া।
 * এটা শুধু aggregate ব্যবহার পরিসংখ্যান (দৈনিক active user, কোন ফিচার কতবার ব্যবহার হলো)
 * দেখায় Firebase Console-এ -- কোনো ব্যক্তিগত তথ্য বা কারো নাম/পরিচয় পাঠায় না।
 */
object AnalyticsHelper {

    fun logAppOpen(context: Context) {
        logEvent(context, FirebaseAnalytics.Event.APP_OPEN, null)
    }

    fun logFeatureUsed(context: Context, featureName: String) {
        val bundle = Bundle().apply { putString("feature_name", featureName) }
        logEvent(context, "feature_used", bundle)
    }

    fun logTranslationDone(context: Context, source: String) {
        val bundle = Bundle().apply { putString("source", source) }
        logEvent(context, "translation_completed", bundle)
    }

    private fun logEvent(context: Context, name: String, params: Bundle?) {
        try {
            FirebaseAnalytics.getInstance(context.applicationContext).logEvent(name, params)
        } catch (_: Exception) {
            // Firebase কনফিগার করা না থাকলে এখানেই নিঃশব্দে থেমে যায়, অ্যাপ চলতে থাকে স্বাভাবিকভাবে
        }
    }
}
