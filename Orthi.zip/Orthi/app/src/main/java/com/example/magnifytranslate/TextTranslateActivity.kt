package com.example.magnifytranslate

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/** টাইপ বা পেস্ট করা ইংরেজি লেখা বাংলায় অনুবাদ করার স্ক্রিন। */
class TextTranslateActivity : AppCompatActivity() {

    private lateinit var etInput: EditText
    private lateinit var tvResult: TextView
    private lateinit var btnTranslate: Button
    private lateinit var btnCopy: ImageButton
    private var lastTranslated: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_text_translate)

        etInput = findViewById(R.id.etInput)
        tvResult = findViewById(R.id.tvResult)
        btnTranslate = findViewById(R.id.btnTranslate)
        btnCopy = findViewById(R.id.btnCopy)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        btnTranslate.setOnClickListener { translate() }
        btnCopy.setOnClickListener { copyResult() }
    }

    private fun translate() {
        val english = etInput.text?.toString()?.trim().orEmpty()
        if (english.isEmpty()) {
            Toast.makeText(this, getString(R.string.empty_input_warning), Toast.LENGTH_SHORT).show()
            return
        }

        tvResult.text = getString(R.string.translating)
        btnCopy.visibility = android.view.View.GONE
        btnTranslate.isEnabled = false

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        btnTranslate.isEnabled = true
                        lastTranslated = translated
                        tvResult.text = translated
                        btnCopy.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "text", english, translated)
                    }
                    .addOnFailureListener {
                        btnTranslate.isEnabled = true
                        tvResult.text = getString(R.string.no_text_found)
                    }
            }
            .addOnFailureListener {
                btnTranslate.isEnabled = true
                tvResult.text = getString(R.string.no_text_found)
            }
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
