package com.example.magnifytranslate

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/** এই স্ক্রিন শুধু স্ক্রিন ম্যাগনিফাইং বাবল (FloatingBubbleService) চালু/বন্ধ করা নিয়ন্ত্রণ করে। */
class BubbleTranslateActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var btnUpdate: Button
    private var pendingUpdate: UpdateChecker.UpdateInfo? = null

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "বাবল চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkBatteryOptimizationAndStart()
        }

    private val batteryOptimizationLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            // ইউজার অনুমতি দিক বা না দিক, তারপরও বাবল চালু করার চেষ্টা চালিয়ে যাই
            launchScreenCapture()
        }

    private val installPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            pendingUpdate?.let { startDownloadAndInstall(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bubble_translate)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        btnUpdate = findViewById(R.id.btnUpdate)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        btnStart.setOnClickListener {
            if (FloatingBubbleService.isRunning) stopBubble() else checkPermissionsAndStart()
        }

        btnUpdate.setOnClickListener {
            pendingUpdate?.let { update -> checkInstallPermissionAndDownload(update) }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi()
        checkForAppUpdate()
    }

    // ---------- অ্যাপ-ভেতরের আপডেট চেকার ----------

    private fun checkForAppUpdate() {
        UpdateChecker.checkForUpdate(BuildConfig.VERSION_CODE) { update ->
            pendingUpdate = update
            btnUpdate.visibility = if (update != null) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun checkInstallPermissionAndDownload(update: UpdateChecker.UpdateInfo) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, getString(R.string.install_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )
            installPermissionLauncher.launch(intent)
            return
        }
        startDownloadAndInstall(update)
    }

    private fun startDownloadAndInstall(update: UpdateChecker.UpdateInfo) {
        Toast.makeText(this, getString(R.string.update_downloading), Toast.LENGTH_LONG).show()
        UpdateChecker.downloadAndInstall(this, update)
    }

    // ---------- বাবল UI/লজিক ----------

    private fun updateStatusUi() {
        if (FloatingBubbleService.isRunning) {
            tvStatus.text = getString(R.string.status_running)
            btnStart.text = getString(R.string.stop_button)
            btnStart.backgroundTintList = getColorStateList(R.color.danger)
        } else {
            tvStatus.text = getString(R.string.status_stopped)
            btnStart.text = getString(R.string.start_button)
            btnStart.backgroundTintList = getColorStateList(R.color.teal)
        }
    }

    private fun stopBubble() {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "বাবল বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        checkBatteryOptimizationAndStart()
    }

    /** Xiaomi/MIUI-সহ অনেক ফোন ব্যাটারি বাঁচাতে ব্যাকগ্রাউন্ড সার্ভিস নিঃশব্দে বন্ধ করে দেয় --
     *  এই অনুরোধ ছাড়া বাবল কিছুক্ষণ পর নিজে থেকে বন্ধ হয়ে যেতে পারে। একবার অনুমতি পেলে
     *  পরেরবার থেকে আর জিজ্ঞেস করবে না। */
    private fun checkBatteryOptimizationAndStart() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        val alreadyIgnoring = powerManager.isIgnoringBatteryOptimizations(packageName)

        if (!alreadyIgnoring) {
            try {
                val intent = Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
                batteryOptimizationLauncher.launch(intent)
                return
            } catch (_: Exception) {
                // কোনো কারণে এই সেটিংস স্ক্রিন খোলা না গেলেও বাবল চালু করা আটকাবে না
            }
        }
        launchScreenCapture()
    }

    private fun launchScreenCapture() {
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
