package com.example.magnifytranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * এই স্ক্রিন দুইটা ফিচার নিয়ন্ত্রণ করে:
 *  ১. স্ক্রিন ম্যাগনিফাইং বাবল (FloatingBubbleService) -- ট্যাপ করে অনুবাদ
 *  ২. "Hey Orthi" ভয়েস মোড (WakeWordService) -- মুখে বলে অনুবাদ
 * (আগে এই লজিক MainActivity-তে ছিল; এখন Home Screen থেকে আলাদা স্ক্রিনে সরানো হয়েছে।)
 */
class BubbleTranslateActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var btnVoice: Button
    private lateinit var tvVoiceStatus: TextView
    private lateinit var btnUpdate: Button
    private var pendingUpdate: UpdateChecker.UpdateInfo? = null

    // ---------- বাবল ফিচারের পারমিশন ফ্লো ----------

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "বাবল চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkPermissionsAndStart()
        }

    private val installPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            pendingUpdate?.let { startDownloadAndInstall(it) }
        }

    // ---------- ভয়েস মোডের পারমিশন ফ্লো ----------

    private val micPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startVoiceService()
            } else {
                Toast.makeText(this, getString(R.string.mic_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bubble_translate)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        btnVoice = findViewById(R.id.btnVoice)
        tvVoiceStatus = findViewById(R.id.tvVoiceStatus)
        btnUpdate = findViewById(R.id.btnUpdate)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        btnStart.setOnClickListener {
            if (FloatingBubbleService.isRunning) stopBubble() else checkPermissionsAndStart()
        }

        btnVoice.setOnClickListener {
            if (WakeWordService.isRunning) stopVoiceService() else checkMicPermissionAndStart()
        }

        btnUpdate.setOnClickListener {
            pendingUpdate?.let { update -> checkInstallPermissionAndDownload(update) }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi()
        checkForAppUpdate()
    }

    // ---------- অ্যাপ-ভেতরের আপডেট চেকার ----------

    private fun checkForAppUpdate() {
        UpdateChecker.checkForUpdate(BuildConfig.VERSION_CODE) { update ->
            pendingUpdate = update
            btnUpdate.visibility = if (update != null) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun checkInstallPermissionAndDownload(update: UpdateChecker.UpdateInfo) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, getString(R.string.install_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )
            installPermissionLauncher.launch(intent)
            return
        }
        startDownloadAndInstall(update)
    }

    private fun startDownloadAndInstall(update: UpdateChecker.UpdateInfo) {
        Toast.makeText(this, getString(R.string.update_downloading), Toast.LENGTH_LONG).show()
        UpdateChecker.downloadAndInstall(this, update)
    }

    // ---------- বাবল UI/লজিক ----------

    private fun updateStatusUi() {
        if (FloatingBubbleService.isRunning) {
            tvStatus.text = getString(R.string.status_running)
            btnStart.text = getString(R.string.stop_button)
            btnStart.backgroundTintList = getColorStateList(R.color.danger)
        } else {
            tvStatus.text = getString(R.string.status_stopped)
            btnStart.text = getString(R.string.start_button)
            btnStart.backgroundTintList = getColorStateList(R.color.teal)
        }

        if (WakeWordService.isRunning) {
            tvVoiceStatus.text = getString(R.string.voice_status_running)
            btnVoice.text = getString(R.string.voice_stop_button)
        } else {
            tvVoiceStatus.text = getString(R.string.voice_status_stopped)
            btnVoice.text = getString(R.string.voice_start_button)
        }
    }

    private fun stopBubble() {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "বাবল বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    // ---------- ভয়েস মোড UI/লজিক ----------

    private fun checkMicPermissionAndStart() {
        // ভয়েস মোডেরও ওভারলে (পপ-আপ দেখানোর) পারমিশন লাগবে
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }

        val hasMicPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasMicPermission) {
            startVoiceService()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceService() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        ActivityCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "ভয়েস মোড চালু ✅ — এখন \"Hey Orthi\" বলুন", Toast.LENGTH_LONG).show()
        updateStatusUi()
    }

    private fun stopVoiceService() {
        val stopIntent = Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "ভয়েস মোড বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }
}
