package com.example.magnifytranslate

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistoryAdapter(
    private var items: List<HistoryEntry>,
    private val onCopy: (HistoryEntry) -> Unit,
    private val onDelete: (HistoryEntry) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvEnglish: TextView = view.findViewById(R.id.tvEnglish)
        val tvBengali: TextView = view.findViewById(R.id.tvBengali)
        val tvSource: TextView = view.findViewById(R.id.tvSource)
        val btnCopy: ImageButton = view.findViewById(R.id.btnCopy)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDelete)
    }

    fun updateItems(newItems: List<HistoryEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]
        holder.tvEnglish.text = entry.english
        holder.tvBengali.text = entry.bengali
        holder.tvSource.text = when (entry.source) {
            "bubble" -> "🔍 Bubble"
            "image" -> "🖼️ Image"
            "voice" -> "🎙️ Voice"
            else -> "⌨️ Text"
        }
        holder.btnCopy.setOnClickListener { onCopy(entry) }
        holder.btnDelete.setOnClickListener { onDelete(entry) }
    }

    override fun getItemCount(): Int = items.size
}
