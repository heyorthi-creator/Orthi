package com.example.magnifytranslate

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class OnboardingActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "orthi_onboarding"
        private const val KEY_SHOWN = "shown"

        fun hasBeenShown(context: Context): Boolean {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            return prefs.getBoolean(KEY_SHOWN, false)
        }

        private fun markShown(context: Context) {
            val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_SHOWN, true).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        findViewById<android.view.View>(R.id.btnGetStarted).setOnClickListener {
            markShown(this)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
