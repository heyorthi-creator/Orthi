package com.example.magnifytranslate

import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Text Translate, Image Translate, History, আর Settings -- এই চারটার জন্যই আপাতত
 * একই রকম একটা "শীঘ্রই আসছে" স্ক্রিন ব্যবহার হচ্ছে। পরে একটা একটা করে
 * আসল ফিচার দিয়ে এই জায়গাগুলো ভরে ফেলা হবে (একই নামের Activity রেখে, ভেতরের কাজ বদলে)।
 */
class ComingSoonActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_SUBTITLE = "extra_subtitle"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coming_soon)

        val title = intent.getStringExtra(EXTRA_TITLE) ?: getString(R.string.coming_soon_default_title)
        val subtitle = intent.getStringExtra(EXTRA_SUBTITLE) ?: getString(R.string.coming_soon_default_subtitle)

        findViewById<TextView>(R.id.tvComingSoonTitle).text = title
        findViewById<TextView>(R.id.tvComingSoonSubtitle).text = subtitle
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
    }
}
