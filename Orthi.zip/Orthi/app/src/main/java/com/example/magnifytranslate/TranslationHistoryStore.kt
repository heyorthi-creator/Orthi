package com.example.magnifytranslate

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * সব অনুবাদের History সংরক্ষণ করে (SharedPreferences-এ JSON আকারে)।
 * Bubble, Text ও Image -- তিন ধরনের অনুবাদই এখানে জমা হয়, প্রতিটার সাথে "source" ট্যাগ থাকে।
 */
data class HistoryEntry(
    val id: Long,
    val source: String,     // "bubble", "text", অথবা "image"
    val english: String,
    val bengali: String,
    val timestamp: Long
)

object TranslationHistoryStore {
    private const val PREFS_NAME = "orthi_history"
    private const val KEY_ENTRIES = "entries"
    private const val MAX_ENTRIES = 500

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    fun add(context: Context, source: String, english: String, bengali: String) {
        if (english.isBlank() || bengali.isBlank()) return
        val all = getAll(context).toMutableList()

        // হুবহু একই লেখা বারবার (যেমন বাবল স্থির থাকলে) সেভ করব না
        if (all.isNotEmpty() && all[0].english == english && all[0].bengali == bengali) return

        val entry = HistoryEntry(
            id = System.currentTimeMillis(),
            source = source,
            english = english,
            bengali = bengali,
            timestamp = System.currentTimeMillis()
        )
        all.add(0, entry)
        val trimmed = if (all.size > MAX_ENTRIES) all.subList(0, MAX_ENTRIES) else all
        saveAll(context, trimmed)
    }

    fun getAll(context: Context): List<HistoryEntry> {
        val raw = prefs(context).getString(KEY_ENTRIES, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryEntry(
                    id = o.getLong("id"),
                    source = o.getString("source"),
                    english = o.getString("english"),
                    bengali = o.getString("bengali"),
                    timestamp = o.getLong("timestamp")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun search(context: Context, query: String): List<HistoryEntry> {
        if (query.isBlank()) return getAll(context)
        val q = query.trim()
        return getAll(context).filter {
            it.english.contains(q, ignoreCase = true) || it.bengali.contains(q, ignoreCase = true)
        }
    }

    @Synchronized
    fun delete(context: Context, id: Long) {
        val remaining = getAll(context).filterNot { it.id == id }
        saveAll(context, remaining)
    }

    @Synchronized
    fun clear(context: Context) {
        prefs(context).edit().remove(KEY_ENTRIES).apply()
    }

    private fun saveAll(context: Context, entries: List<HistoryEntry>) {
        val arr = JSONArray()
        entries.forEach { e ->
            val o = JSONObject()
            o.put("id", e.id)
            o.put("source", e.source)
            o.put("english", e.english)
            o.put("bengali", e.bengali)
            o.put("timestamp", e.timestamp)
            arr.put(o)
        }
        prefs(context).edit().putString(KEY_ENTRIES, arr.toString()).apply()
    }
}
