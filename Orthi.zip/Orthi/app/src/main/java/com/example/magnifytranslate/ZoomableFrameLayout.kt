package com.example.magnifytranslate

import android.content.Context
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.FrameLayout
import kotlin.math.max
import kotlin.math.min

/**
 * ছবি আর তার উপরের অনুবাদ-overlay একসাথে পিঞ্চ করে বড়/ছোট করা যায় (Google Lens-এর
 * মতো) -- দুটো child view-ই এই একই container-এর ভেতরে থাকে, তাই container-টাকে
 * scale/translate করলে দুটোই নিখুঁতভাবে সিঙ্কে থেকে যায়, আলাদা করে matrix মেলাতে হয় না।
 * সাধারণ ট্যাপ (ছবির কোনো লাইনে ট্যাপ করে কপি করা) zoom না থাকলে স্বাভাবিকভাবেই কাজ করে।
 */
class ZoomableFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    private var scale = 1f
    private var panX = 0f
    private var panY = 0f
    private val minScale = 1f
    private val maxScale = 4f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val newScale = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
            val factor = newScale / scale
            scale = newScale
            // ফোকাস পয়েন্ট ধরে রেখেই জুম করি, যাতে যেখানে আঙুল রাখা হয়েছে সেটাই কেন্দ্রে থাকে
            panX = (panX - detector.focusX) * factor + detector.focusX
            panY = (panY - detector.focusY) * factor + detector.focusY
            clampPan()
            applyTransform()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            scale = 1f
            panX = 0f
            panY = 0f
            applyTransform()
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scale <= 1f) return false
            panX -= dx
            panY -= dy
            clampPan()
            applyTransform()
            return true
        }
    })

    private fun clampPan() {
        val maxPanX = width * (scale - 1) / 2f
        val maxPanY = height * (scale - 1) / 2f
        panX = panX.coerceIn(-maxPanX, maxPanX)
        panY = panY.coerceIn(-maxPanY, maxPanY)
    }

    private fun applyTransform() {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            child.scaleX = scale
            child.scaleY = scale
            child.translationX = panX
            child.translationY = panY
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        // দুই আঙুল (পিঞ্চ) হলে সবসময় নিজেই handle করি; এক আঙুল হলে শুধু আগে থেকে
        // zoom করা থাকলেই pan-এর জন্য intercept করি -- নাহলে সাধারণ ট্যাপ
        // (ছবির লাইনে ট্যাপ করে কপি করা) স্বাভাবিকভাবেই child-এ পৌঁছাবে
        return ev.pointerCount > 1 || scale > 1f
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    /** জুম রিসেট করে -- নতুন ছবি লোড করার সময় ডাকা উচিত */
    fun resetZoom() {
        scale = 1f
        panX = 0f
        panY = 0f
        applyTransform()
    }
}
