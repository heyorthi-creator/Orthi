package com.example.magnifytranslate

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** সব অনুবাদের History দেখা, খোঁজা, কপি ও মোছার স্ক্রিন। */
class HistoryActivity : AppCompatActivity() {

    private lateinit var rvHistory: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var etSearch: EditText
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        rvHistory = findViewById(R.id.rvHistory)
        tvEmpty = findViewById(R.id.tvEmpty)
        etSearch = findViewById(R.id.etSearch)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnDeleteAll).setOnClickListener { confirmClearAll() }

        adapter = HistoryAdapter(
            items = emptyList(),
            onCopy = { entry -> copyToClipboard(entry.bengali) },
            onDelete = { entry -> deleteEntry(entry.id) }
        )
        rvHistory.layoutManager = LinearLayoutManager(this)
        rvHistory.adapter = adapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                loadHistory(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        loadHistory(etSearch.text?.toString().orEmpty())
    }

    private fun loadHistory(query: String) {
        val entries = TranslationHistoryStore.search(this, query)
        adapter.updateItems(entries)
        tvEmpty.visibility = if (entries.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        rvHistory.visibility = if (entries.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun deleteEntry(id: Long) {
        TranslationHistoryStore.delete(this, id)
        loadHistory(etSearch.text?.toString().orEmpty())
    }

    private fun confirmClearAll() {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.history_delete_confirm))
            .setPositiveButton(getString(R.string.history_delete_all)) { _, _ ->
                TranslationHistoryStore.clear(this)
                loadHistory(etSearch.text?.toString().orEmpty())
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    private fun copyToClipboard(text: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
