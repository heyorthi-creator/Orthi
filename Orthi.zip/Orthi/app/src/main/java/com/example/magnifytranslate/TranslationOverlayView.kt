package com.example.magnifytranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * ছবির উপর সরাসরি বাংলা অনুবাদ বসিয়ে দেখায় (Google Lens-এর "Translated" ভিউয়ের মতো) --
 * প্রতিটা লাইনের ঠিক জায়গায় (bounding box) একটা রঙিন ব্যাকগ্রাউন্ড বসিয়ে তার উপর
 * বাংলা লেখা আঁকা হয়। ছবিটা fitCenter দিয়ে দেখানো হয় বলে scale+offset হিসাব সহজ।
 */
class TranslationOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class Box(val rect: RectF, val text: String)

    var boxes: List<Box> = emptyList()
        set(value) {
            field = value
            invalidate()
        }
    var sourceWidth: Int = 1
    var sourceHeight: Int = 1

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E01F7A6C")
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (boxes.isEmpty() || sourceWidth <= 0 || sourceHeight <= 0 || width <= 0 || height <= 0) return

        // fitCenter ম্যাপিং: বিটম্যাপ কো-অর্ডিনেট থেকে ভিউ কো-অর্ডিনেটে রূপান্তর
        val scale = minOf(width.toFloat() / sourceWidth, height.toFloat() / sourceHeight)
        val dx = (width - sourceWidth * scale) / 2f
        val dy = (height - sourceHeight * scale) / 2f

        for (box in boxes) {
            val left = box.rect.left * scale + dx
            val top = box.rect.top * scale + dy
            val right = box.rect.right * scale + dx
            val bottom = box.rect.bottom * scale + dy
            if (right <= left || bottom <= top) continue

            canvas.drawRoundRect(left, top, right, bottom, 6f, 6f, bgPaint)

            val boxHeight = bottom - top
            var textSize = (boxHeight * 0.58f).coerceIn(16f, 60f)
            textPaint.textSize = textSize
            var tw = textPaint.measureText(box.text)
            val maxWidth = (right - left) - 10f
            while (tw > maxWidth && textSize > 10f) {
                textSize -= 1f
                textPaint.textSize = textSize
                tw = textPaint.measureText(box.text)
            }

            val textY = top + (boxHeight + textSize * 0.7f) / 2f
            canvas.drawText(box.text, left + 5f, textY, textPaint)
        }
    }
}
