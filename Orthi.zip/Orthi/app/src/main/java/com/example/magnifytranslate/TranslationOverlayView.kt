package com.example.magnifytranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * ছবির উপর সরাসরি বাংলা অনুবাদ বসিয়ে দেখায় (Google Lens-এর "Translated" ভিউয়ের মতো) --
 * প্রতিটা লাইনের ঠিক জায়গায় (bounding box) একটা রঙিন ব্যাকগ্রাউন্ড বসিয়ে তার উপর
 * বাংলা লেখা আঁকা হয়। ছবিটা fitCenter দিয়ে দেখানো হয় বলে scale+offset হিসাব সহজ।
 * ছবির যেকোনো লাইনে ট্যাপ করলেই সেই লাইনের বাংলা লেখা সরাসরি কপি হয়ে যায় --
 * তাই অনুবাদ করা লেখা ছবি থেকেই সরাসরি কপি করা যায়, আলাদা বাটন খুঁজতে হয় না।
 */
class TranslationOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    data class Box(val rect: RectF, val text: String)

    var boxes: List<Box> = emptyList()
        set(value) {
            field = value
            invalidate()
        }
    var sourceWidth: Int = 1
    var sourceHeight: Int = 1
    var onBoxTapped: ((String) -> Unit)? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E01F7A6C")
        style = Paint.Style.FILL
    }
    private val bgPaintTapped = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E0C98A2E")
        style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
    }

    private var tappedIndex = -1

    private fun viewRectFor(box: Box, scale: Float, dx: Float, dy: Float): RectF {
        return RectF(
            box.rect.left * scale + dx,
            box.rect.top * scale + dy,
            box.rect.right * scale + dx,
            box.rect.bottom * scale + dy
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (boxes.isEmpty() || sourceWidth <= 0 || sourceHeight <= 0 || width <= 0 || height <= 0) {
            return super.onTouchEvent(event)
        }
        if (event.action != MotionEvent.ACTION_UP) return true

        val scale = minOf(width.toFloat() / sourceWidth, height.toFloat() / sourceHeight)
        val dx = (width - sourceWidth * scale) / 2f
        val dy = (height - sourceHeight * scale) / 2f

        val hitIndex = boxes.indexOfFirst { box ->
            viewRectFor(box, scale, dx, dy).contains(event.x, event.y)
        }
        if (hitIndex >= 0) {
            tappedIndex = hitIndex
            invalidate()
            onBoxTapped?.invoke(boxes[hitIndex].text)
            postDelayed({ tappedIndex = -1; invalidate() }, 220)
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (boxes.isEmpty() || sourceWidth <= 0 || sourceHeight <= 0 || width <= 0 || height <= 0) return

        // fitCenter ম্যাপিং: বিটম্যাপ কো-অর্ডিনেট থেকে ভিউ কো-অর্ডিনেটে রূপান্তর
        val scale = minOf(width.toFloat() / sourceWidth, height.toFloat() / sourceHeight)
        val dx = (width - sourceWidth * scale) / 2f
        val dy = (height - sourceHeight * scale) / 2f

        boxes.forEachIndexed { index, box ->
            val r = viewRectFor(box, scale, dx, dy)
            if (r.right <= r.left || r.bottom <= r.top) return@forEachIndexed

            val paint = if (index == tappedIndex) bgPaintTapped else bgPaint
            canvas.drawRoundRect(r, 6f, 6f, paint)

            val boxHeight = r.bottom - r.top
            var textSize = (boxHeight * 0.58f).coerceIn(16f, 60f)
            textPaint.textSize = textSize
            var tw = textPaint.measureText(box.text)
            val maxWidth = (r.right - r.left) - 10f
            while (tw > maxWidth && textSize > 10f) {
                textSize -= 1f
                textPaint.textSize = textSize
                tw = textPaint.measureText(box.text)
            }

            val textY = r.top + (boxHeight + textSize * 0.7f) / 2f
            canvas.drawText(box.text, r.left + 5f, textY, textPaint)
        }
    }
}
