package com.example.magnifytranslate

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

/**
 * Settings স্ক্রিন থেকে Light/Dark/System মোড বেছে নেওয়ার জন্য।
 * প্রতিটা Activity-র onCreate()-এ setContentView()-এর আগে apply() ডাকতে হবে।
 */
object ThemeManager {
    private const val PREFS_NAME = "orthi_settings"
    private const val KEY_THEME_MODE = "theme_mode"

    const val MODE_SYSTEM = 0
    const val MODE_LIGHT = 1
    const val MODE_DARK = 2

    fun getMode(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_THEME_MODE, MODE_SYSTEM)
    }

    fun setMode(context: Context, mode: Int) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply()
        apply(context)
    }

    fun apply(context: Context) {
        val night = when (getMode(context)) {
            MODE_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
            MODE_DARK -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(night)
    }
}
