package com.example.magnifytranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

/**
 * সম্পূর্ণ ফ্রি ভয়েস মোড -- কোনো তৃতীয় পক্ষের সার্ভিস, অ্যাকাউন্ট, ট্রায়াল বা AccessKey লাগে না।
 * Android এর নিজস্ব বিল্ট-ইন Speech Recognition ব্যবহার করে কাজ করে।
 *
 * কীভাবে কাজ করে:
 *  ১. এই সার্ভিস বারবার (loop করে) ছোট ছোট সেশনে মাইক্রোফোন শোনে
 *  ২. প্রতিটা সেশনের পর যা শোনা গেছে তার মধ্যে "hey orthi" বাক্যাংশ আছে কিনা চেক করে
 *  ৩. পেলে -- সাথে যদি আরও কথা বলা থাকে (যেমন "hey orthi how are you") সেটাই অনুবাদ করে,
 *     না থাকলে পরের কথাটা শোনার জন্য আরেকটা সেশন চালায়
 *  ৪. অনুবাদ স্ক্রিনে দেখায় এবং বাংলায় জোরে পড়ে শোনায় (TTS)
 *  ৫. আবার "hey orthi" শোনার জন্য loop চালু থাকে
 *
 * নোট: এটা Google-এর ডিফল্ট স্পিচ রিকগনিশন সার্ভিস ব্যবহার করে যা বেশিরভাগ Android ফোনে
 * আগে থেকেই থাকে (কোনো আলাদা সাইন-আপ লাগে না)।
 */
class WakeWordService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.magnifytranslate.action.STOP_VOICE"
        private const val CHANNEL_ID = "hey_orthi_voice_channel"
        private const val NOTIFICATION_ID = 2
        private val WAKE_PHRASES = listOf("hey orthi", "hey ortho", "hey aarthi", "hey orthy")

        @Volatile var isRunning = false
            private set
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private lateinit var windowManager: WindowManager
    private var popupView: View? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var waitingForCommand = false
    private var stopped = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("bn", "BD")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopped = true
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        isRunning = true
        stopped = false
        startListeningLoop()
        return START_STICKY
    }

    // ---------- মূল শোনা-লুপ ----------

    private fun startListeningLoop() {
        if (stopped) return

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    ?: ""
                handleHeard(text)
            }

            override fun onError(error: Int) {
                // কিছু না শুনলে বা টাইমআউট হলেও লুপ চালিয়ে যাই
                restartLoopSoon()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun restartLoopSoon() {
        if (stopped) return
        // একটুখানি বিরতি দিয়ে আবার শোনা শুরু করি, যাতে টাইট লুপে ব্যাটারি না খায়
        mainHandler.postDelayed({ startListeningLoop() }, 400)
    }

    private fun handleHeard(text: String) {
        val lower = text.lowercase(Locale.US)

        if (waitingForCommand) {
            // আগের সেশনে "hey orthi" বলা হয়েছিল, এখন এটাই কমান্ড
            waitingForCommand = false
            if (text.isNotBlank()) {
                translateAndSpeak(text)
            }
            restartLoopSoon()
            return
        }

        val matchedPhrase = WAKE_PHRASES.firstOrNull { lower.contains(it) }
        if (matchedPhrase != null) {
            val afterWake = lower.substringAfter(matchedPhrase).trim()
            if (afterWake.isNotBlank()) {
                // "hey orthi" এর পরেও একই বাক্যে কথা বলা হয়েছে, সেটাই ধরে নেই
                translateAndSpeak(afterWake)
                restartLoopSoon()
            } else {
                // শুধু "hey orthi" বলা হয়েছে, এখন পরের কথাটার জন্য অপেক্ষা করি
                showPopup(getString(R.string.voice_listening_for_speech))
                waitingForCommand = true
                startListeningLoop()
            }
        } else {
            // "hey orthi" শোনা যায়নি -- চুপচাপ আবার শোনা শুরু করি
            restartLoopSoon()
        }
    }

    // ---------- অনুবাদ ও বাংলায় পড়ে শোনানো ----------

    private fun translateAndSpeak(englishText: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(englishText)
                    .addOnSuccessListener { translated ->
                        showPopup(translated)
                        textToSpeech?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "orthi_tts")
                    }
                    .addOnFailureListener {
                        showPopup(getString(R.string.no_text_found))
                    }
            }
            .addOnFailureListener {
                showPopup("অনুবাদ মডেল ডাউনলোড করতে ইন্টারনেট লাগবে")
            }
    }

    // ---------- ফলাফল দেখানোর পপ-আপ ----------

    private fun showPopup(text: String) {
        removePopup()

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.popup_translation, null)
        view.findViewById<TextView>(R.id.tvTranslated).text = text
        view.findViewById<TextView>(R.id.tvClose).setOnClickListener { removePopup() }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 220

        windowManager.addView(view, params)
        popupView = view

        // ৫ সেকেন্ড পর পপ-আপ নিজে থেকেই বন্ধ হয়ে যাবে
        mainHandler.postDelayed({ removePopup() }, 5000)
    }

    private fun removePopup() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        popupView = null
    }

    // ---------- নোটিফিকেশন ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hey Orthi Voice Mode",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = android.app.PendingIntent.getService(
            this, 0, stopIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.voice_status_running))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopped = true
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        removePopup()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
