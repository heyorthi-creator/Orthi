package com.example.magnifytranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.Locale

/**
 * সম্পূর্ণ ফ্রি ভয়েস মোড -- কোনো তৃতীয় পক্ষের সার্ভিস, অ্যাকাউন্ট, ট্রায়াল বা AccessKey লাগে না।
 * Android এর নিজস্ব বিল্ট-ইন Speech Recognition ব্যবহার করে কাজ করে।
 *
 * নির্ভরযোগ্যতার জন্য যা যা করা হয়েছে:
 *  ১. একই SpeechRecognizer instance বারবার পুনর্ব্যবহার হয় (প্রতিবার নতুন করে তৈরি না করায় গ্যাপ কমে)
 *  ২. "কিছু শোনা যায়নি" (NO_MATCH/TIMEOUT) হলে প্রায় সাথে সাথেই আবার শোনা শুরু হয় -- তাই
 *     "Hey Orthi" বলার মাঝের ফাঁকা সময়টা যতটা সম্ভব কমানো হয়েছে
 *  ৩. সাইলেন্স-টাইমিং একটু বাড়ানো হয়েছে যাতে কথা বলার মাঝে ছোট বিরতিতে বাক্য কেটে না যায়
 *  ৪. আংশিক ফলাফল (partial results) থেকেও wake word চেক হয়, যাতে অ্যানিমেশন সাথে সাথে সাড়া দেয়
 *  ৫. Google Assistant-এর মতো একটা স্পন্দিত (pulsing) "শুনছি" আইকন সবসময় স্ক্রিনে দেখা যায়,
 *     যেটা অবস্থাভেদে রঙ/গতি বদলে জানায় এখন কী হচ্ছে
 */
class WakeWordService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.magnifytranslate.action.STOP_VOICE"
        private const val CHANNEL_ID = "hey_orthi_voice_channel"
        private const val NOTIFICATION_ID = 2
        private val WAKE_PHRASES = listOf(
            "hey orthi", "hey ortho", "hey aarthi", "hey orthy",
            "hey aarti", "hey already", "hey author", "hey audi"
        )

        @Volatile var isRunning = false
            private set
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private lateinit var windowManager: WindowManager
    private var popupView: View? = null
    private var indicatorView: VoiceListeningIndicatorView? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var waitingForCommand = false
    private var stopped = false

    private val recognitionListener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                ?: ""
            handleHeard(text)
        }

        override fun onError(error: Int) {
            if (waitingForCommand) {
                // কমান্ডের অপেক্ষায় থাকা অবস্থায় কিছু শোনা না গেলে আবার wake word মোডে ফিরে যাই
                waitingForCommand = false
                indicatorView?.setState(VoiceListeningIndicatorView.State.LISTENING)
            }
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    // সবচেয়ে সাধারণ ঘটনা -- সাথে সাথে আবার শোনা শুরু করি যাতে wake word মিস না হয়
                    restartLoopFast()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    mainHandler.postDelayed({ startListeningLoop() }, 1000)
                }
                else -> {
                    // নেটওয়ার্ক/অডিও/সার্ভার সমস্যা -- একটু বিরতি দিয়ে আবার চেষ্টা করি
                    mainHandler.postDelayed({ startListeningLoop() }, 1500)
                }
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (waitingForCommand) return
            val partialText = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase(Locale.US) ?: return
            if (WAKE_PHRASES.any { partialText.contains(it) }) {
                // এখনো চূড়ান্ত ফলাফল আসেনি, কিন্তু অ্যানিমেশনটা এখনই সাড়া দিক যাতে মনে হয় শুনতে পাচ্ছে
                indicatorView?.setState(VoiceListeningIndicatorView.State.HEARD_WAKE)
            }
        }

        override fun onRmsChanged(rmsdB: Float) {
            // rmsdB সাধারণত প্রায় -2 থেকে 10 এর মধ্যে থাকে -- এটাকে ০..১ পরিসরে আনা হলো
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            indicatorView?.setMicLevel(normalized)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("bn", "BD")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopped = true
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        isRunning = true
        stopped = false
        showIndicator()
        startListeningLoop()
        return START_STICKY
    }

    // ---------- মূল শোনা-লুপ ----------

    private fun startListeningLoop() {
        if (stopped) return

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(recognitionListener)
        }

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            // কথার মাঝে ছোট বিরতিতে বাক্য যাতে অসম্পূর্ণ অবস্থায় কেটে না যায়
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800)
        }

        try {
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            // recognizer instance নষ্ট হয়ে থাকলে নতুন করে তৈরি করে আবার চেষ্টা করি
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(recognitionListener)
            try { speechRecognizer?.startListening(recognizerIntent) } catch (_: Exception) {}
        }
    }

    private fun restartLoopFast() {
        if (stopped) return
        // খুবই ছোট বিরতি -- শুধু tight synchronous loop এড়াতে, wake word মিস করার ঝুঁকি কমাতে
        mainHandler.postDelayed({ startListeningLoop() }, 120)
    }

    private fun handleHeard(text: String) {
        val lower = text.lowercase(Locale.US)

        if (waitingForCommand) {
            // আগের সেশনে "hey orthi" বলা হয়েছিল, এখন এটাই কমান্ড
            waitingForCommand = false
            if (text.isNotBlank()) {
                indicatorView?.setState(VoiceListeningIndicatorView.State.PROCESSING)
                translateAndSpeak(text)
            } else {
                indicatorView?.setState(VoiceListeningIndicatorView.State.LISTENING)
            }
            restartLoopFast()
            return
        }

        val matchedPhrase = WAKE_PHRASES.firstOrNull { lower.contains(it) }
        if (matchedPhrase != null) {
            val afterWake = lower.substringAfter(matchedPhrase).trim()
            if (afterWake.isNotBlank()) {
                // "hey orthi" এর পরেও একই বাক্যে কথা বলা হয়েছে, সেটাই ধরে নেই
                indicatorView?.setState(VoiceListeningIndicatorView.State.PROCESSING)
                translateAndSpeak(afterWake)
                restartLoopFast()
            } else {
                // শুধু "hey orthi" বলা হয়েছে, এখন পরের কথাটার জন্য অপেক্ষা করি
                indicatorView?.setState(VoiceListeningIndicatorView.State.HEARD_WAKE)
                showPopup(getString(R.string.voice_listening_for_speech))
                waitingForCommand = true
                startListeningLoop()
            }
        } else {
            // "hey orthi" শোনা যায়নি -- চুপচাপ আবার শোনা শুরু করি
            restartLoopFast()
        }
    }

    // ---------- অনুবাদ ও বাংলায় পড়ে শোনানো ----------

    private fun translateAndSpeak(englishText: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(englishText)
                    .addOnSuccessListener { translated ->
                        showPopup(translated)
                        TranslationHistoryStore.add(this, "voice", englishText, translated)
                        textToSpeech?.speak(translated, TextToSpeech.QUEUE_FLUSH, null, "orthi_tts")
                        indicatorView?.setState(VoiceListeningIndicatorView.State.LISTENING)
                    }
                    .addOnFailureListener {
                        showPopup(getString(R.string.no_text_found))
                        indicatorView?.setState(VoiceListeningIndicatorView.State.LISTENING)
                    }
            }
            .addOnFailureListener {
                showPopup("অনুবাদ মডেল ডাউনলোড করতে ইন্টারনেট লাগবে")
                indicatorView?.setState(VoiceListeningIndicatorView.State.LISTENING)
            }
    }

    // ---------- ফলাফল দেখানোর পপ-আপ ----------

    private fun showPopup(text: String) {
        removePopup()

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.popup_translation, null)
        view.findViewById<TextView>(R.id.tvTranslated).text = text
        view.findViewById<TextView>(R.id.tvClose).setOnClickListener { removePopup() }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 220

        windowManager.addView(view, params)
        popupView = view

        // ৫ সেকেন্ড পর পপ-আপ নিজে থেকেই বন্ধ হয়ে যাবে
        mainHandler.postDelayed({ removePopup() }, 5000)
    }

    private fun removePopup() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        popupView = null
    }

    // ---------- "শুনছি" ইন্ডিকেটর (Google Assistant-এর মতো অ্যানিমেশন) ----------

    private fun showIndicator() {
        if (indicatorView != null) return

        val view = VoiceListeningIndicatorView(this)
        val sizePx = (92 * resources.displayMetrics.density).toInt()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            sizePx, sizePx, layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        params.y = 140

        try {
            windowManager.addView(view, params)
            indicatorView = view
        } catch (_: Exception) {}
    }

    private fun removeIndicator() {
        indicatorView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        indicatorView = null
    }

    // ---------- নোটিফিকেশন ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hey Orthi Voice Mode",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = android.app.PendingIntent.getService(
            this, 0, stopIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.voice_status_running))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopped = true
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        speechRecognizer = null
        removePopup()
        removeIndicator()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
