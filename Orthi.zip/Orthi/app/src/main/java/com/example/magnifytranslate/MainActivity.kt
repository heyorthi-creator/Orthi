package com.example.magnifytranslate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * MainActivity শুধু দুইটা কাজ করে:
 * ১. "Overlay" পারমিশন আছে কিনা চেক করে, না থাকলে সেটিংসে পাঠায়
 * ২. স্ক্রিন-ক্যাপচারের পারমিশন চায় (MediaProjection), পেলে FloatingBubbleService চালু করে
 *
 * আসল কাজ (bubble দেখানো, ক্যাপচার, OCR, অনুবাদ) সব FloatingBubbleService এর ভেতরে হয়,
 * কারণ bubble টা অন্য সব অ্যাপের উপরেও ভাসতে থাকবে -- MainActivity বন্ধ করলেও।
 */
class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                // পারমিশন পাওয়া গেছে -- এখন bubble সার্ভিস চালু করি
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "বাবল চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish() // অ্যাক্টিভিটি বন্ধ করলেও সার্ভিস চলতে থাকবে
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkPermissionsAndStart()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            checkPermissionsAndStart()
        }
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        // Overlay পারমিশন আছে -> এবার স্ক্রিন-ক্যাপচার পারমিশন চাই
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
