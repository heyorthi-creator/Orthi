package com.example.magnifytranslate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * হোম স্ক্রিন -- ব্লুপ্রিন্ট অনুযায়ী ৪টা অপশন: Bubble Translate, Text Translate,
 * Image Translate, History (+ উপরে ডান পাশে Settings আইকন)।
 * এখন পর্যন্ত শুধু Bubble Translate সত্যিকারের কাজ করে (FloatingBubbleService),
 * বাকিগুলো "শীঘ্রই আসছে" স্ক্রিনে যায় -- ধাপে ধাপে একটা একটা করে বানানো হবে।
 */
class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var tileBubble: LinearLayout
    private lateinit var tvTileBubbleLabel: TextView
    private lateinit var tvTileBubbleSub: TextView
    private lateinit var btnUpdate: TextView
    private var pendingUpdate: UpdateChecker.UpdateInfo? = null

    // ---------- বাবল ফিচারের পারমিশন ফ্লো ----------

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "লেন্স চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkPermissionsAndStart()
        }

    private val installPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            pendingUpdate?.let { startDownloadAndInstall(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        tileBubble = findViewById(R.id.tileBubble)
        tvTileBubbleLabel = findViewById(R.id.tvTileBubbleLabel)
        tvTileBubbleSub = findViewById(R.id.tvTileBubbleSub)
        btnUpdate = findViewById(R.id.btnUpdate)

        tileBubble.setOnClickListener {
            if (FloatingBubbleService.isRunning) stopBubble() else checkPermissionsAndStart()
        }

        findViewById<LinearLayout>(R.id.tileText).setOnClickListener {
            openComingSoon(getString(R.string.tile_text_title), getString(R.string.coming_soon_text_subtitle))
        }
        findViewById<LinearLayout>(R.id.tileImage).setOnClickListener {
            openComingSoon(getString(R.string.tile_image_title), getString(R.string.coming_soon_image_subtitle))
        }
        findViewById<LinearLayout>(R.id.tileHistory).setOnClickListener {
            openComingSoon(getString(R.string.tile_history_title), getString(R.string.coming_soon_history_subtitle))
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            openComingSoon(getString(R.string.settings_title), getString(R.string.coming_soon_settings_subtitle))
        }

        btnUpdate.setOnClickListener {
            pendingUpdate?.let { update -> checkInstallPermissionAndDownload(update) }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi()
        checkForAppUpdate()
    }

    private fun openComingSoon(title: String, subtitle: String) {
        val intent = Intent(this, ComingSoonActivity::class.java).apply {
            putExtra(ComingSoonActivity.EXTRA_TITLE, title)
            putExtra(ComingSoonActivity.EXTRA_SUBTITLE, subtitle)
        }
        startActivity(intent)
    }

    // ---------- অ্যাপ-ভেতরের আপডেট চেকার ----------

    private fun checkForAppUpdate() {
        UpdateChecker.checkForUpdate(BuildConfig.VERSION_CODE) { update ->
            pendingUpdate = update
            btnUpdate.visibility = if (update != null) View.VISIBLE else View.GONE
        }
    }

    private fun checkInstallPermissionAndDownload(update: UpdateChecker.UpdateInfo) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, getString(R.string.install_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )
            installPermissionLauncher.launch(intent)
            return
        }
        startDownloadAndInstall(update)
    }

    private fun startDownloadAndInstall(update: UpdateChecker.UpdateInfo) {
        Toast.makeText(this, getString(R.string.update_downloading), Toast.LENGTH_LONG).show()
        UpdateChecker.downloadAndInstall(this, update)
    }

    // ---------- বাবল/লেন্স UI ----------

    private fun updateStatusUi() {
        if (FloatingBubbleService.isRunning) {
            tvTileBubbleLabel.text = getString(R.string.tile_bubble_title)
            tvTileBubbleSub.text = getString(R.string.tile_bubble_subtitle_running)
            tileBubble.setBackgroundResource(R.drawable.bg_tile_running)
        } else {
            tvTileBubbleLabel.text = getString(R.string.tile_bubble_title)
            tvTileBubbleSub.text = getString(R.string.tile_bubble_subtitle)
            tileBubble.setBackgroundResource(R.drawable.bg_tile_primary)
        }
    }

    private fun stopBubble() {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "লেন্স বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
