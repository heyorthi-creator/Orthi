package com.example.magnifytranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * MainActivity এখন দুইটা ফিচার নিয়ন্ত্রণ করে:
 *  ১. স্ক্রিন ম্যাগনিফাইং বাবল (FloatingBubbleService) -- ট্যাপ করে অনুবাদ
 *  ২. "Hey Orthi" ভয়েস মোড (WakeWordService) -- মুখে বলে অনুবাদ
 */
class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView
    private lateinit var btnVoice: Button
    private lateinit var tvVoiceStatus: TextView

    // ---------- বাবল ফিচারের পারমিশন ফ্লো ----------

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "বাবল চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkPermissionsAndStart()
        }

    // ---------- ভয়েস মোডের পারমিশন ফ্লো ----------

    private val micPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                startVoiceService()
            } else {
                Toast.makeText(this, getString(R.string.mic_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)
        btnVoice = findViewById(R.id.btnVoice)
        tvVoiceStatus = findViewById(R.id.tvVoiceStatus)

        btnStart.setOnClickListener {
            if (FloatingBubbleService.isRunning) stopBubble() else checkPermissionsAndStart()
        }

        btnVoice.setOnClickListener {
            if (WakeWordService.isRunning) stopVoiceService() else checkMicPermissionAndStart()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi()
    }

    // ---------- বাবল UI/লজিক ----------

    private fun updateStatusUi() {
        if (FloatingBubbleService.isRunning) {
            tvStatus.text = getString(R.string.status_running)
            btnStart.text = getString(R.string.stop_button)
            btnStart.backgroundTintList = getColorStateList(R.color.danger)
        } else {
            tvStatus.text = getString(R.string.status_stopped)
            btnStart.text = getString(R.string.start_button)
            btnStart.backgroundTintList = getColorStateList(R.color.teal)
        }

        if (WakeWordService.isRunning) {
            tvVoiceStatus.text = getString(R.string.voice_status_running)
            btnVoice.text = getString(R.string.voice_stop_button)
        } else {
            tvVoiceStatus.text = getString(R.string.voice_status_stopped)
            btnVoice.text = getString(R.string.voice_start_button)
        }
    }

    private fun stopBubble() {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "বাবল বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    // ---------- ভয়েস মোড UI/লজিক ----------

    private fun checkMicPermissionAndStart() {
        // ভয়েস মোডেরও ওভারলে (পপ-আপ দেখানোর) পারমিশন লাগবে
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }

        val hasMicPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasMicPermission) {
            startVoiceService()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceService() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        ActivityCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "ভয়েস মোড চালু ✅ — এখন \"Hey Orthi\" বলুন", Toast.LENGTH_LONG).show()
        updateStatusUi()
    }

    private fun stopVoiceService() {
        val stopIntent = Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "ভয়েস মোড বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }
}
