package com.example.magnifytranslate

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * Home Screen -- ব্রিফ অনুযায়ী শুধু ৪টা অপশন (Bubble/Text/Image Translate, History)
 * + ডানে Settings আইকন। বাবল/ভয়েস কন্ট্রোল এখন BubbleTranslateActivity-তে।
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        findViewById<android.view.View>(R.id.cardBubbleTranslate).setOnClickListener {
            startActivity(Intent(this, BubbleTranslateActivity::class.java))
        }
        findViewById<android.view.View>(R.id.cardTextTranslate).setOnClickListener {
            startActivity(Intent(this, TextTranslateActivity::class.java))
        }
        findViewById<android.view.View>(R.id.cardImageTranslate).setOnClickListener {
            startActivity(Intent(this, ImageTranslateActivity::class.java))
        }
        findViewById<android.view.View>(R.id.cardHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<android.view.View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // Home Screen-ই সবার আগে খোলে, তাই এখানেও আপডেট আছে কিনা চেক করি -- ইউজারকে
        // আলাদা করে Bubble Translate স্ক্রিনে গিয়ে দেখতে হবে না
        UpdateChecker.checkForUpdate(BuildConfig.VERSION_CODE) { update ->
            if (update != null) {
                Toast.makeText(
                    this,
                    getString(R.string.update_available_toast, update.tagName),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
