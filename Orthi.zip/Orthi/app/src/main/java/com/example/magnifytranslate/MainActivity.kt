package com.example.magnifytranslate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

/**
 * MainActivity এখন দুইটা অবস্থা দেখায়/নিয়ন্ত্রণ করে:
 *  - বাবল বন্ধ থাকলে: "বাবল চালু করুন" বাটনে চাপলে পারমিশন চেয়ে বাবল চালু করে
 *  - বাবল চালু থাকলে: বাটন বদলে "বাবল বন্ধ করুন" দেখায়, চাপলে সার্ভিস বন্ধ করে দেয়
 *
 * আসল কাজ (bubble দেখানো, ক্যাপচার, OCR, অনুবাদ) সব FloatingBubbleService এর ভেতরে হয়।
 */
class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, FloatingBubbleService::class.java).apply {
                    putExtra(FloatingBubbleService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(FloatingBubbleService.EXTRA_RESULT_DATA, result.data)
                }
                ActivityCompat.startForegroundService(this, serviceIntent)
                Toast.makeText(this, "বাবল চালু হয়েছে ✅", Toast.LENGTH_SHORT).show()
                finish() // অ্যাক্টিভিটি বন্ধ করলেও সার্ভিস চলতে থাকবে
            } else {
                Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            }
        }

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkPermissionsAndStart()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        btnStart = findViewById(R.id.btnStart)
        tvStatus = findViewById(R.id.tvStatus)

        btnStart.setOnClickListener {
            if (FloatingBubbleService.isRunning) {
                stopBubble()
            } else {
                checkPermissionsAndStart()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatusUi()
    }

    private fun updateStatusUi() {
        if (FloatingBubbleService.isRunning) {
            tvStatus.text = getString(R.string.status_running)
            btnStart.text = getString(R.string.stop_button)
            btnStart.backgroundTintList = getColorStateList(R.color.danger)
        } else {
            tvStatus.text = getString(R.string.status_stopped)
            btnStart.text = getString(R.string.start_button)
            btnStart.backgroundTintList = getColorStateList(R.color.teal)
        }
    }

    private fun stopBubble() {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = FloatingBubbleService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "বাবল বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateStatusUi()
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
