package com.example.magnifytranslate

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Play Store ছাড়াই অ্যাপের ভেতর থেকে "আপডেট আছে কিনা" চেক করে, থাকলে ডাউনলোড করে
 * ইনস্টল স্ক্রিন খুলে দেয় -- GitHub Releases ব্যবহার করে (এটা পাবলিক রিপোর জন্য
 * কোনো লগইন/টোকেন ছাড়াই অ্যাক্সেসযোগ্য, তাই ফোন থেকে সরাসরি কল করা যায়)।
 *
 * বাস্তবতা: Android-এর নিরাপত্তা নিয়মের কারণে সম্পূর্ণ "silent" (স্পর্শ ছাড়া) ইনস্টল
 * সম্ভব না -- শেষে একবার "Install" বাটনে চাপ দিতে হবেই। এটাই সবচেয়ে কাছাকাছি automatic flow:
 * অ্যাপ খুললেই নিজে থেকে চেক করবে, ডাউনলোড করবে, ইনস্টল স্ক্রিন খুলে দেবে।
 */
object UpdateChecker {

    // ⚠️ এই দুইটা GitHub username/repo-র সাথে মিলিয়ে রাখা আছে -- বদলালে এখানেও বদলাতে হবে
    private const val REPO_OWNER = "heyorthi-creator"
    private const val REPO_NAME = "Orthi"
    private const val RELEASES_API = "https://api.github.com/repos/$REPO_OWNER/$REPO_NAME/releases/latest"

    data class UpdateInfo(val versionCode: Int, val apkUrl: String, val tagName: String)

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * ব্যাকগ্রাউন্ড থ্রেডে GitHub-এর "latest release" চেক করে।
     * নতুন ভার্সন থাকলে callback-এ UpdateInfo দেয়, না থাকলে বা এরর হলে null দেয়।
     * callback সবসময় মেইন (UI) থ্রেডে চলে।
     */
    fun checkForUpdate(currentVersionCode: Int, callback: (UpdateInfo?) -> Unit) {
        Thread {
            val result: UpdateInfo? = try {
                val connection = URL(RELEASES_API).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("Accept", "application/vnd.github+json")
                connection.connectTimeout = 8000
                connection.readTimeout = 8000

                if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                    connection.disconnect()
                    null
                } else {
                    val body = connection.inputStream.bufferedReader().use { it.readText() }
                    connection.disconnect()

                    val json = JSONObject(body)
                    val tagName = json.optString("tag_name", "")
                    val remoteVersionCode = tagName.removePrefix("v").toIntOrNull()

                    if (remoteVersionCode == null || remoteVersionCode <= currentVersionCode) {
                        null
                    } else {
                        val assets = json.optJSONArray("assets")
                        var apkUrl: String? = null
                        if (assets != null) {
                            for (i in 0 until assets.length()) {
                                val asset = assets.getJSONObject(i)
                                if (asset.optString("name", "").endsWith(".apk")) {
                                    apkUrl = asset.optString("browser_download_url", null)
                                    break
                                }
                            }
                        }
                        if (apkUrl != null) UpdateInfo(remoteVersionCode, apkUrl, tagName) else null
                    }
                }
            } catch (_: Exception) {
                null
            }
            mainHandler.post { callback(result) }
        }.start()
    }

    /**
     * Android-এর নিজস্ব DownloadManager দিয়ে APK ফাইলটা ব্যাকগ্রাউন্ডে ডাউনলোড করে,
     * শেষ হলে নিজে থেকেই ইনস্টল স্ক্রিন খুলে দেয়।
     */
    fun downloadAndInstall(context: Context, update: UpdateInfo) {
        val fileName = "orthi-update-${update.tagName}.apk"

        // আগের কোনো আধাখেঁচড়া ডাউনলোড থাকলে মুছে নতুন করে শুরু করি
        val targetFile = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        if (targetFile.exists()) targetFile.delete()

        val request = DownloadManager.Request(Uri.parse(update.apkUrl))
            .setTitle("Orthi আপডেট ডাউনলোড হচ্ছে (${update.tagName})")
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)

        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val downloadId = downloadManager.enqueue(request)

        val appContext = context.applicationContext
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                val finishedId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                if (finishedId == downloadId) {
                    try { appContext.unregisterReceiver(this) } catch (_: Exception) {}
                    if (targetFile.exists()) {
                        installApk(appContext, targetFile)
                    }
                }
            }
        }

        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            appContext.registerReceiver(receiver, filter)
        }
    }

    private fun installApk(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    }
}
