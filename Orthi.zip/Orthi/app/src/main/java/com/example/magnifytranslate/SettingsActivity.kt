package com.example.magnifytranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var rgTheme: RadioGroup
    private lateinit var btnVoice: Button
    private lateinit var tvVoiceStatus: TextView

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkMicPermissionAndStart()
        }

    private val micPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startVoiceService() else
                Toast.makeText(this, getString(R.string.mic_permission_needed), Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        rgTheme = findViewById(R.id.rgTheme)
        when (ThemeManager.getMode(this)) {
            ThemeManager.MODE_LIGHT -> rgTheme.check(R.id.rbLight)
            ThemeManager.MODE_DARK -> rgTheme.check(R.id.rbDark)
            else -> rgTheme.check(R.id.rbSystem)
        }
        rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbLight -> ThemeManager.MODE_LIGHT
                R.id.rbDark -> ThemeManager.MODE_DARK
                else -> ThemeManager.MODE_SYSTEM
            }
            ThemeManager.setMode(this, mode)
        }

        findViewById<android.view.View>(R.id.btnClearHistory).setOnClickListener {
            confirmClearHistory()
        }

        btnVoice = findViewById(R.id.btnVoice)
        tvVoiceStatus = findViewById(R.id.tvVoiceStatus)
        btnVoice.setOnClickListener {
            if (WakeWordService.isRunning) stopVoiceService() else checkOverlayThenMicPermission()
        }

        findViewById<TextView>(R.id.tvVersion).text =
            getString(R.string.version_label, BuildConfig.VERSION_NAME)
    }

    override fun onResume() {
        super.onResume()
        updateVoiceStatusUi()
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.history_delete_confirm))
            .setPositiveButton(getString(R.string.history_delete_all)) { _, _ ->
                TranslationHistoryStore.clear(this)
                Toast.makeText(this, getString(R.string.history_cleared_toast), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    // ---------- Voice Mode (এক্সপেরিমেন্টাল) ----------

    private fun updateVoiceStatusUi() {
        if (WakeWordService.isRunning) {
            tvVoiceStatus.text = getString(R.string.voice_status_running)
            btnVoice.text = getString(R.string.voice_stop_button)
        } else {
            tvVoiceStatus.text = getString(R.string.voice_status_stopped)
            btnVoice.text = getString(R.string.voice_start_button)
        }
    }

    private fun checkOverlayThenMicPermission() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, getString(R.string.overlay_permission_needed), Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlaySettingsLauncher.launch(intent)
            return
        }
        checkMicPermissionAndStart()
    }

    private fun checkMicPermissionAndStart() {
        val hasMicPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasMicPermission) startVoiceService() else
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoiceService() {
        val serviceIntent = Intent(this, WakeWordService::class.java)
        ActivityCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "ভয়েস মোড চালু ✅ — এখন \"Hey Orthi\" বলুন", Toast.LENGTH_LONG).show()
        updateVoiceStatusUi()
    }

    private fun stopVoiceService() {
        val stopIntent = Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_STOP
        }
        startService(stopIntent)
        Toast.makeText(this, "ভয়েস মোড বন্ধ হয়েছে", Toast.LENGTH_SHORT).show()
        updateVoiceStatusUi()
    }
}
