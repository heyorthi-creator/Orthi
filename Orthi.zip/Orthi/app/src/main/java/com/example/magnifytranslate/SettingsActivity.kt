package com.example.magnifytranslate

import android.os.Bundle
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var rgTheme: RadioGroup

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }

        rgTheme = findViewById(R.id.rgTheme)
        when (ThemeManager.getMode(this)) {
            ThemeManager.MODE_LIGHT -> rgTheme.check(R.id.rbLight)
            ThemeManager.MODE_DARK -> rgTheme.check(R.id.rbDark)
            else -> rgTheme.check(R.id.rbSystem)
        }
        rgTheme.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.rbLight -> ThemeManager.MODE_LIGHT
                R.id.rbDark -> ThemeManager.MODE_DARK
                else -> ThemeManager.MODE_SYSTEM
            }
            ThemeManager.setMode(this, mode)
        }

        findViewById<android.view.View>(R.id.btnClearHistory).setOnClickListener {
            confirmClearHistory()
        }

        findViewById<android.view.View>(R.id.btnCheckUpdate).setOnClickListener {
            checkForUpdateManually()
        }

        findViewById<TextView>(R.id.tvVersion).text =
            getString(R.string.version_label, BuildConfig.VERSION_NAME)
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.history_delete_confirm))
            .setPositiveButton(getString(R.string.history_delete_all)) { _, _ ->
                TranslationHistoryStore.clear(this)
                Toast.makeText(this, getString(R.string.history_cleared_toast), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.close), null)
            .show()
    }

    /** ইউজার যেকোনো সময় নিজে থেকেই চেক করতে পারবে নতুন ভার্সন আছে কিনা --
     *  শুধু চুপচাপ ব্যাকগ্রাউন্ড চেকের ওপর নির্ভর না করে। */
    private fun checkForUpdateManually() {
        Toast.makeText(this, getString(R.string.checking_update), Toast.LENGTH_SHORT).show()
        UpdateChecker.checkForUpdate(BuildConfig.VERSION_CODE) { update ->
            if (update != null) {
                AlertDialog.Builder(this)
                    .setTitle(getString(R.string.update_available_toast, update.tagName))
                    .setMessage(getString(R.string.update_downloading))
                    .setPositiveButton(getString(R.string.go_update_button)) { _, _ ->
                        startActivity(
                            android.content.Intent(this, BubbleTranslateActivity::class.java)
                        )
                    }
                    .setNegativeButton(getString(R.string.close), null)
                    .show()
            } else {
                Toast.makeText(this, getString(R.string.already_latest_version), Toast.LENGTH_LONG).show()
            }
        }
    }
}
