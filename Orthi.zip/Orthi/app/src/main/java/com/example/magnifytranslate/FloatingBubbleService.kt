package com.example.magnifytranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * সহজ, নির্ভরযোগ্য বাবল: ব্রিফ অনুযায়ী --
 *  ১. ছোট গোলাকার বাবল টেনে ইংরেজি লেখার উপর নিয়ে ছাড়তে হবে (বা শুধু ট্যাপ করলেও চলবে)
 *  ২. তখন একবারই ক্যাপচার হয়, আর বাবলের পাশে একটা Card-এ বাংলা অনুবাদ + Copy + Close দেখা যায়
 *  ৩. নতুন জায়গায় নিয়ে আবার ছাড়লে আবার নতুন অনুবাদ
 * (আগে প্রতি ৭০০ms-এ বারবার automatic ক্যাপচার হতো -- এটা জটিল, ব্যাটারি-খরুচে ও
 * কিছু ডিভাইসে অনির্ভরযোগ্য ছিল। এখন শুধু action-এ (tap/release) capture হয়।)
 */
class FloatingBubbleService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val ACTION_STOP = "com.example.magnifytranslate.action.STOP"
        private const val CHANNEL_ID = "magnify_translate_channel"
        private const val NOTIFICATION_ID = 1
        private const val CAPTURE_SIZE_DP = 170 // অ্যাংকর বিন্দুর চারপাশের এলাকা ক্যাপচার হয়, যাতে OCR ভালো কাজ করে

        @Volatile var isRunning = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: View
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var popupView: View? = null
    private var popupParams: WindowManager.LayoutParams? = null
    private var lastTranslatedText: String? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var isBubbleShowing = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isTranslating = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        startForeground(NOTIFICATION_ID, buildNotification())

        if (resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        showBubble()
        return START_STICKY
    }

    // ---------- ফোরগ্রাউন্ড নোটিফিকেশন ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_zoom)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    // ---------- স্ক্রিন ক্যাপচার সেটআপ ----------

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        try {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)

            // Android 14+ (API 34) থেকে createVirtualDisplay()-এর আগে callback রেজিস্টার
            // করা বাধ্যতামূলক -- এটা ছাড়া অনেক ডিভাইসে ক্যাপচার নিঃশব্দে ব্যর্থ হয়।
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    mainHandler.post { stopSelf() }
                }
            }, mainHandler)

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "MagnifyTranslateCapture",
                screenWidth, screenHeight, screenDensity,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, null
            )
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.capture_permission_needed), Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    // ---------- ভাসমান বাবল ----------

    private fun showBubble() {
        if (isBubbleShowing) return

        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubbleParams.x = 40
        bubbleParams.y = 400

        windowManager.addView(bubbleView, bubbleParams)
        isBubbleShowing = true
        attachDragListener()
    }

    /** বাবল টেনে সরানো যাবে; ছেড়ে দিলে (বা শুধু ট্যাপ করলে) সেই জায়গার একবার ক্যাপচার হবে;
     *  ~৬০০ মিলিসেকেন্ড চেপে ধরে রাখলে বাবল বন্ধ হয়ে যাবে। */
    private fun attachDragListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var downTime = 0L
        val longPressMs = 600L

        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    downTime = System.currentTimeMillis()
                    removePopup()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX)
                    val dy = (event.rawY - initialTouchY)
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        isDragging = true
                        bubbleParams.x = initialX + dx.toInt()
                        bubbleParams.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val pressDuration = System.currentTimeMillis() - downTime
                    if (!isDragging && pressDuration >= longPressMs) {
                        stopSelf()
                    } else {
                        // ট্যাপ অথবা ড্র্যাগ শেষে ছেড়ে দেওয়া -- দুটোতেই এখন একবার ক্যাপচার হবে
                        triggerCapture()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ---------- অনুবাদ কার্ড (popup) ----------

    private fun showPopupLoading() {
        removePopup()

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.popup_translation, null)
        val tvTranslated = view.findViewById<TextView>(R.id.tvTranslated)
        val tvCopy = view.findViewById<TextView>(R.id.tvCopy)
        val tvClose = view.findViewById<TextView>(R.id.tvClose)

        tvTranslated.text = getString(R.string.translating)
        tvClose.setOnClickListener { removePopup() }
        tvCopy.setOnClickListener {
            lastTranslatedText?.let { text ->
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
                Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
            }
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        // কার্ডটা বাবলের পাশে বসাই -- স্ক্রিনের নিচের/উপরের কিনারায় গেলে দিক পাল্টে যায়
        val cardWidthPx = (280 * resources.displayMetrics.density).toInt()
        var popupX = bubbleParams.x + 70
        if (popupX + cardWidthPx > screenWidth) {
            popupX = (bubbleParams.x - cardWidthPx - 16).coerceAtLeast(8)
        }
        var popupY = bubbleParams.y - 20
        if (popupY < 60) popupY = bubbleParams.y + 70

        params.x = popupX
        params.y = popupY

        popupView = view
        popupParams = params
        windowManager.addView(view, params)
    }

    private fun updatePopupText(text: String) {
        val view = popupView ?: return
        view.findViewById<TextView>(R.id.tvTranslated).text = text
    }

    private fun removePopup() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        popupView = null
        popupParams = null
    }

    // ---------- ক্যাপচার -> OCR -> অনুবাদ (একবারই, action-এ) ----------

    private fun triggerCapture() {
        if (isTranslating) return
        isTranslating = true
        showPopupLoading()

        // বাবলটা নিজেই ঠিক যেখানে ইউজার আঙুল রেখেছে সেখানে বসে থাকে -- ক্যাপচারের সময়
        // ওটা visible থাকলে নিজের নিচের লেখাটাই ঢেকে ফেলে (ঠিক যেটা অনুবাদ করার কথা)।
        // তাই ক্যাপচারের ঠিক আগে বাবলটা সাময়িকভাবে লুকিয়ে ফেলি, স্ক্রিন রিড্র হওয়ার জন্য
        // সামান্য সময় দিই, তারপর ক্যাপচার করেই আবার দেখিয়ে দিই।
        bubbleView.visibility = View.INVISIBLE
        mainHandler.postDelayed({ captureAndTranslate() }, 120)
    }

    private fun captureAndTranslate() {
        val reader = imageReader
        if (reader == null) {
            bubbleView.visibility = View.VISIBLE
            isTranslating = false
            updatePopupText(getString(R.string.lens_error_hint))
            return
        }

        // বাবল লুকানোর আগের পুরনো (stale) ফ্রেম যেন ব্যবহার না হয়, তাই বাফারে জমে থাকা
        // সব ফ্রেম আগে খালি করে দিয়ে একদম শেষেরটা নিই
        var image: Image? = null
        try {
            while (true) {
                val next = reader.acquireLatestImage() ?: break
                image?.close()
                image = next
            }
        } catch (_: Exception) { /* যা পাওয়া গেছে তাই দিয়ে চালিয়ে যাই */ }

        bubbleView.visibility = View.VISIBLE // ক্যাপচার নেওয়া হয়ে গেছে, এখন আবার দেখানো যাক

        if (image == null) {
            isTranslating = false
            updatePopupText(getString(R.string.lens_error_hint))
            return
        }

        val bitmap = imageToBitmap(image)
        image.close()

        val cropped = cropAroundAnchor(bitmap)
        recognizeAndTranslate(cropped)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    private fun cropAroundAnchor(bitmap: Bitmap): Bitmap {
        val density = screenDensity / 160f
        val sizePx = (CAPTURE_SIZE_DP * density).toInt()

        val location = IntArray(2)
        bubbleView.getLocationOnScreen(location)
        val anchorCenterX = location[0] + bubbleView.width / 2
        val anchorCenterY = location[1] + bubbleView.height / 2

        val centerX = anchorCenterX.coerceIn(0, bitmap.width - 1)
        val centerY = anchorCenterY.coerceIn(0, bitmap.height - 1)

        val left = (centerX - sizePx / 2).coerceIn(0, bitmap.width - sizePx.coerceAtMost(bitmap.width))
        val top = (centerY - sizePx / 2).coerceIn(0, bitmap.height - sizePx.coerceAtMost(bitmap.height))
        val width = sizePx.coerceAtMost(bitmap.width - left)
        val height = sizePx.coerceAtMost(bitmap.height - top)

        return Bitmap.createBitmap(bitmap, left, top, width, height)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                when {
                    recognized.isEmpty() -> {
                        isTranslating = false
                        updatePopupText(getString(R.string.lens_no_text_hint))
                    }
                    !looksLikeTranslatableEnglish(recognized) -> {
                        // হোম স্ক্রিনের আইকন লেবেল বা এলোমেলো টুকরো লেখা (যেমন "সরঞ্জাম", "Mes")
                        // ধরে ভুল অনুবাদ দেখানোর বদলে স্পষ্টভাবে জানিয়ে দিই
                        isTranslating = false
                        updatePopupText(getString(R.string.lens_not_clear_hint))
                    }
                    else -> translateText(recognized)
                }
            }
            .addOnFailureListener {
                isTranslating = false
                updatePopupText(getString(R.string.lens_no_text_hint))
            }
    }

    /**
     * OCR যা পড়েছে সেটা আসলেই অনুবাদযোগ্য একটা ইংরেজি বাক্য/বাক্যাংশ কিনা যাচাই করে --
     * শুধু একটা-দুইটা অক্ষরের টুকরো (যেমন অ্যাপ আইকনের লেবেল থেকে "Mes", "bK") বা
     * অ-ইংরেজি লেখা (বাংলা ইত্যাদি) চলে এলে সেটা বাতিল করে, যাতে ভুল/অর্থহীন অনুবাদ না দেখায়।
     */
    private fun looksLikeTranslatableEnglish(text: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 4) return false // খুব ছোট টুকরো (যেমন আইকন লেবেল)

        val latinCount = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
        val latinRatio = latinCount.toFloat() / letters.length
        if (latinRatio < 0.7f) return false // মূলত বাংলা/অন্য স্ক্রিপ্ট হলে অনুবাদের দরকার নেই

        // পুরো ক্যাপচারে অন্তত একটা মানানসই শব্দ (৩+ অক্ষর) বা একাধিক শব্দ থাকা চাই,
        // যাতে বিচ্ছিন্ন ছোট ছোট আইকন-লেবেলের সমষ্টি অনুবাদ না হয়ে যায়
        val words = text.split(Regex("\\s+")).filter { it.any(Char::isLetter) }
        val hasDecentWord = words.any { it.filter(Char::isLetter).length >= 3 }
        return words.size >= 2 || hasDecentWord
    }

    private fun translateText(english: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        lastTranslatedText = translated
                        updatePopupText(translated)
                        TranslationHistoryStore.add(this, "bubble", english, translated)
                        isTranslating = false
                    }
                    .addOnFailureListener {
                        updatePopupText(getString(R.string.lens_error_hint))
                        isTranslating = false
                    }
            }
            .addOnFailureListener {
                updatePopupText(getString(R.string.lens_download_error_hint))
                isTranslating = false
            }
    }

    // ---------- পরিষ্কার করা ----------

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        isBubbleShowing = false
        mainHandler.removeCallbacksAndMessages(null)
        removePopup()
        try { windowManager.removeView(bubbleView) } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
