package com.example.magnifytranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Phase 2: সত্যিকারের "ম্যাগনিফাইং লেন্স" -- ছোট্ট 🔎 বিন্দুটা টেনে ইংরেজি লেখার উপর নিলে
 * তার ঠিক উপরে ভাসমান বড় লেন্সের ভেতরে বাংলা অনুবাদ দেখা যায় (আঙুলের আড়ালে না থেকে,
 * পড়ার জন্য যথেষ্ট বড় ও স্পষ্ট)। নতুন জায়গায় নিলে নিজে থেকেই নতুন অনুবাদ আসে।
 * এক জায়গায় স্থির থাকলে বারবার ক্যাপচার হয় না (ব্যাটারি বাঁচাতে), শুধু নড়াচড়া করলেই নতুন ক্যাপচার হয়।
 * ক্যাপচারের কেন্দ্রবিন্দু সবসময় নিচের ছোট্ট 🔎 বিন্দুটার আসল স্ক্রিন-অবস্থান থেকে হিসাব হয় --
 * তাই লেন্সের আকার/অবস্থান যতই বদলাক, আসল ইংরেজি লেখাটাই ধরা পড়ে।
 */
class FloatingBubbleService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val ACTION_STOP = "com.example.magnifytranslate.action.STOP"
        private const val CHANNEL_ID = "magnify_translate_channel"
        private const val NOTIFICATION_ID = 1
        private const val CAPTURE_SIZE_DP = 150 // অ্যাংকর বিন্দুর চারপাশের এলাকা ক্যাপচার হয়, যাতে OCR ভালো কাজ করে
        private const val CAPTURE_INTERVAL_MS = 700L // কত ঘন ঘন নতুন ক্যাপচার চেষ্টা হবে
        private const val MOVE_THRESHOLD_PX = 15 // এর কম নড়াচড়ায় নতুন ক্যাপচার হবে না
        private const val DRAG_START_THRESHOLD_PX = 6 // এর বেশি নড়লেই টানা শুরু -- আগে ১২ ছিল, ধরাটা সহজ করতে কমানো হলো

        @Volatile var isRunning = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: View
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var tvLensText: TextView
    private lateinit var anchorDotView: View

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var isBubbleShowing = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastCapturedX = Int.MIN_VALUE
    private var lastCapturedY = Int.MIN_VALUE
    private var isTranslating = false
    private var isLoopRunning = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        startForeground(NOTIFICATION_ID, buildNotification())

        if (resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        showBubble()
        startCaptureLoop()
        return START_STICKY
    }

    // ---------- ফোরগ্রাউন্ড নোটিফিকেশন ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_zoom)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    // ---------- স্ক্রিন ক্যাপচার সেটআপ ----------

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "MagnifyTranslateCapture",
            screenWidth, screenHeight, screenDensity,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    // ---------- ভাসমান লেন্স ----------

    private fun showBubble() {
        if (isBubbleShowing) return

        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)
        tvLensText = bubbleView.findViewById(R.id.tvLensText)
        anchorDotView = bubbleView.findViewById(R.id.anchorDot)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubbleParams.x = 0
        bubbleParams.y = 300

        windowManager.addView(bubbleView, bubbleParams)
        isBubbleShowing = true
        attachDragListener()
    }

    /** লেন্স টেনে সরানো যাবে; ~৬০০ মিলিসেকেন্ড চেপে ধরলে বন্ধ হয়ে যাবে */
    private fun attachDragListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var downTime = 0L
        val longPressMs = 600L

        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX)
                    val dy = (event.rawY - initialTouchY)
                    if (abs(dx) > DRAG_START_THRESHOLD_PX || abs(dy) > DRAG_START_THRESHOLD_PX) {
                        isDragging = true
                        bubbleParams.x = initialX + dx.toInt()
                        bubbleParams.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val pressDuration = System.currentTimeMillis() - downTime
                    if (!isDragging && pressDuration >= longPressMs) {
                        stopSelf()
                    } else if (!isDragging) {
                        // ছোট্ট ট্যাপ -> এখনই আবার ক্যাপচার করি (জোর করে রিফ্রেশ)
                        forceRecapture()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun forceRecapture() {
        lastCapturedX = Int.MIN_VALUE
        lastCapturedY = Int.MIN_VALUE
    }

    // ---------- পর্যায়ক্রমিক ক্যাপচার লুপ (লাইভ অনুবাদের মূল চাবিকাঠি) ----------

    private fun startCaptureLoop() {
        if (isLoopRunning) return
        isLoopRunning = true

        val loopRunnable = object : Runnable {
            override fun run() {
                if (!isBubbleShowing) return
                maybeCaptureAndTranslate()
                mainHandler.postDelayed(this, CAPTURE_INTERVAL_MS)
            }
        }
        mainHandler.post(loopRunnable)
    }

    private fun maybeCaptureAndTranslate() {
        if (isTranslating) return // আগেরটা এখনও চলছে, নতুন করে শুরু করব না

        val moved = abs(bubbleParams.x - lastCapturedX) > MOVE_THRESHOLD_PX ||
            abs(bubbleParams.y - lastCapturedY) > MOVE_THRESHOLD_PX
        if (!moved) return // লেন্স স্থির আছে, আগের অনুবাদই থাক

        lastCapturedX = bubbleParams.x
        lastCapturedY = bubbleParams.y
        captureAndTranslate()
    }

    // ---------- ক্যাপচার -> OCR -> অনুবাদ ----------

    private fun captureAndTranslate() {
        val reader = imageReader ?: return
        val image: Image = try {
            reader.acquireLatestImage()
        } catch (_: Exception) { null } ?: return

        isTranslating = true
        val bitmap = imageToBitmap(image)
        image.close()

        val cropped = cropAroundAnchor(bitmap)
        recognizeAndTranslate(cropped)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    private fun cropAroundAnchor(bitmap: Bitmap): Bitmap {
        val density = screenDensity / 160f
        val sizePx = (CAPTURE_SIZE_DP * density).toInt()

        // লেন্সটা এখন আঙুলের বিন্দুর উপরে ভাসমান, তাই ক্যাপচারের কেন্দ্র হিসাব করতে হবে
        // নিচের ছোট্ট 🔎 বিন্দুর আসল স্ক্রিন-অবস্থান থেকে (bubbleParams থেকে নয়)
        val location = IntArray(2)
        anchorDotView.getLocationOnScreen(location)
        val anchorCenterX = location[0] + anchorDotView.width / 2
        val anchorCenterY = location[1] + anchorDotView.height / 2

        val centerX = anchorCenterX.coerceIn(0, bitmap.width - 1)
        val centerY = anchorCenterY.coerceIn(0, bitmap.height - 1)

        val left = (centerX - sizePx / 2).coerceIn(0, bitmap.width - sizePx.coerceAtMost(bitmap.width))
        val top = (centerY - sizePx / 2).coerceIn(0, bitmap.height - sizePx.coerceAtMost(bitmap.height))
        val width = sizePx.coerceAtMost(bitmap.width - left)
        val height = sizePx.coerceAtMost(bitmap.height - top)

        return Bitmap.createBitmap(bitmap, left, top, width, height)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = firstSentenceOrWhole(visionText.text)
                if (recognized.isEmpty()) {
                    isTranslating = false
                    // এখানে কোনো লেখা নেই -- আগের অনুবাদ মুছে দিচ্ছি না, চুপচাপ থাকি
                } else {
                    translateText(recognized)
                }
            }
            .addOnFailureListener {
                isTranslating = false
            }
    }

    /**
     * শুধু প্রথম সম্পূর্ণ বাক্যটাই অনুবাদ করি -- যেমন "Hello i am rahad." থাকলে
     * শুধু "Hello i am rahad." পর্যন্তই অনুবাদ হবে, এর পরে যা ক্যাপচার হয়েছে তা বাদ যাবে।
     * কিন্তু যদি কোনো দাঁড়ি/ফুলস্টপ (.  !  ?) একদমই না থাকে (যেমন শুধু "Rahad" নামটা),
     * তাহলে পুরো লেখাটাই অনুবাদ হবে -- একটা অসম্পূর্ণ বাক্যের কারণে খালি ফলাফল দেখাবে না।
     */
    private fun firstSentenceOrWhole(rawText: String): String {
        val normalized = rawText.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        if (normalized.isEmpty()) return normalized
        val match = Regex("[.!?…]").find(normalized)
        return if (match != null) {
            normalized.substring(0, match.range.last + 1).trim()
        } else {
            normalized
        }
    }

    private fun translateText(english: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        updateLensText(translated)
                        isTranslating = false
                    }
                    .addOnFailureListener {
                        isTranslating = false
                    }
            }
            .addOnFailureListener {
                isTranslating = false
            }
    }

    private fun updateLensText(text: String) {
        if (!::tvLensText.isInitialized) return
        // লেন্স এখন বড়, তবু বেশি লম্বা টেক্সট হলে ছোট করে দেখাই
        val trimmed = if (text.length > 130) text.take(130) + "…" else text
        tvLensText.text = trimmed
    }

    // ---------- পরিষ্কার করা ----------

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        isBubbleShowing = false
        isLoopRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        try { windowManager.removeView(bubbleView) } catch (_: Exception) {}
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
