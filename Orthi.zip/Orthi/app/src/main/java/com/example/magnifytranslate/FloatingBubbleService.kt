package com.example.magnifytranslate

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * এই সার্ভিসটাই আসল কাজের জায়গা:
 *  - স্ক্রিনে একটা ভাসমান বাবল (bubble) দেখায়, টেনে যেকোনো জায়গায় নেওয়া যায়
 *  - বাবলে ট্যাপ করলে বাবলের আশেপাশের একটা অংশ ক্যাপচার করে
 *  - ক্যাপচার করা অংশ থেকে ইংরেজি লেখা বের করে (OCR)
 *  - সেই লেখা বাংলায় অনুবাদ করে
 *  - বাবলের পাশে একটা পপ-আপে অনুবাদ দেখায়
 *
 * নোট: এটা Phase 1 এর সহজ ভার্সন -- ট্যাপ করলে একবার অনুবাদ হয়।
 * Phase 2 তে এটাকেই রিয়েল-টাইম (drag করলেই বারবার) করা হবে।
 */
class FloatingBubbleService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val ACTION_STOP = "com.example.magnifytranslate.action.STOP"
        private const val CHANNEL_ID = "magnify_translate_channel"
        private const val NOTIFICATION_ID = 1
        private const val CAPTURE_SIZE_DP = 120 // বাবলের চারপাশে কত বড় অংশ ক্যাপচার হবে

        /** MainActivity এইটা দেখেই বুঝবে বাবল এখন চালু আছে কিনা */
        @Volatile var isRunning = false
            private set
    }

    private lateinit var windowManager: WindowManager
    private lateinit var bubbleView: View
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var popupView: View? = null
    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var isBubbleShowing = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        startForeground(NOTIFICATION_ID, buildNotification())

        if (resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }
        showBubble()
        return START_STICKY
    }

    // ---------- ফোরগ্রাউন্ড নোটিফিকেশন (Android নিয়মের জন্য দরকার) ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_zoom)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    // ---------- স্ক্রিন ক্যাপচার সেটআপ ----------

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "MagnifyTranslateCapture",
            screenWidth, screenHeight, screenDensity,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )
    }

    // ---------- ভাসমান বাবল ----------

    private fun showBubble() {
        // আগে থেকেই একটা বাবল দেখানো থাকলে আরেকটা যোগ করব না
        if (isBubbleShowing) return

        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.floating_bubble, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bubbleParams.gravity = Gravity.TOP or Gravity.START
        bubbleParams.x = 0
        bubbleParams.y = 300

        windowManager.addView(bubbleView, bubbleParams)
        isBubbleShowing = true
        attachDragAndTapListener()
    }

    /** বাবল টেনে সরানো যাবে (drag), সামান্য নড়াচড়া হলে ট্যাপ ধরে ক্যাপচার শুরু হবে,
     *  আর প্রায় ৬০০ মিলিসেকেন্ড চেপে ধরে রাখলে (long-press) বাবলটা পুরোপুরি বন্ধ হয়ে যাবে। */
    private fun attachDragAndTapListener() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        var downTime = 0L
        val longPressMs = 600L

        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX)
                    val dy = (event.rawY - initialTouchY)
                    if (abs(dx) > 12 || abs(dy) > 12) {
                        isDragging = true
                        bubbleParams.x = initialX + dx.toInt()
                        bubbleParams.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val pressDuration = System.currentTimeMillis() - downTime
                    when {
                        !isDragging && pressDuration >= longPressMs -> {
                            // long-press -> বাবল ও সার্ভিস বন্ধ করে দাও
                            stopSelf()
                        }
                        !isDragging -> {
                            // সাধারণ ট্যাপ -> ক্যাপচার ও অনুবাদ শুরু করি
                            captureAndTranslate()
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ---------- ক্যাপচার -> OCR -> অনুবাদ ----------

    private fun captureAndTranslate() {
        showPopup(getString(R.string.translating))

        val reader = imageReader ?: return
        val image: Image = reader.acquireLatestImage() ?: run {
            showPopup(getString(R.string.no_text_found))
            return
        }

        val bitmap = imageToBitmap(image)
        image.close()

        val cropped = cropAroundBubble(bitmap)
        recognizeAndTranslate(cropped)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    /** বাবলের চারপাশের ~CAPTURE_SIZE_DP এলাকাটুকু ক্রপ করে বের করি */
    private fun cropAroundBubble(bitmap: Bitmap): Bitmap {
        val density = screenDensity / 160f
        val sizePx = (CAPTURE_SIZE_DP * density).toInt()

        val centerX = (bubbleParams.x + sizePx / 2).coerceIn(0, bitmap.width - 1)
        val centerY = (bubbleParams.y + sizePx / 2).coerceIn(0, bitmap.height - 1)

        val left = (centerX - sizePx / 2).coerceIn(0, bitmap.width - sizePx.coerceAtMost(bitmap.width))
        val top = (centerY - sizePx / 2).coerceIn(0, bitmap.height - sizePx.coerceAtMost(bitmap.height))
        val width = sizePx.coerceAtMost(bitmap.width - left)
        val height = sizePx.coerceAtMost(bitmap.height - top)

        return Bitmap.createBitmap(bitmap, left, top, width, height)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                if (recognized.isEmpty()) {
                    showPopup(getString(R.string.no_text_found))
                } else {
                    translateText(recognized)
                }
            }
            .addOnFailureListener {
                showPopup(getString(R.string.no_text_found))
            }
    }

    private fun translateText(english: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        showPopup(translated)
                    }
                    .addOnFailureListener {
                        showPopup(getString(R.string.no_text_found))
                    }
            }
            .addOnFailureListener {
                // মডেল ডাউনলোড ব্যর্থ হলে (ইন্টারনেট নেই) জানিয়ে দেই
                showPopup("অনুবাদ মডেল ডাউনলোড করতে ইন্টারনেট লাগবে")
            }
    }

    // ---------- ফলাফল পপ-আপ ----------

    private fun showPopup(text: String) {
        removePopup()

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.popup_translation, null)
        view.findViewById<TextView>(R.id.tvTranslated).text = text
        view.findViewById<TextView>(R.id.tvClose).setOnClickListener { removePopup() }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams.x
        params.y = bubbleParams.y + 140

        windowManager.addView(view, params)
        popupView = view
    }

    private fun removePopup() {
        popupView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        popupView = null
    }

    // ---------- পরিষ্কার করা ----------

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        isBubbleShowing = false
        try { windowManager.removeView(bubbleView) } catch (_: Exception) {}
        removePopup()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
