package com.example.magnifytranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.io.OutputStream

/**
 * Gallery/ক্যামেরার ছবি থেকে ইংরেজি লেখা বের করে বাংলায় অনুবাদ করার স্ক্রিন।
 * Google Lens-এর মতো ছবির উপরেই সরাসরি বাংলা বসিয়ে দেখানোর "Translated" ভিউ আছে
 * (Original/Translated টগল), সাথে নিচে সম্পূর্ণ লেখা পড়ার মতো করেও দেখানো থাকে,
 * যা Lens-এ নেই -- কপি করার আর ইতিহাসে সেভ করার সুবিধার জন্য।
 */
class ImageTranslateActivity : AppCompatActivity() {

    companion object {
        private const val MAX_DIMENSION = 1600
    }

    private lateinit var ivPreview: ImageView
    private lateinit var overlayView: TranslationOverlayView
    private lateinit var pbOverlayLoading: ProgressBar
    private lateinit var tabToggle: android.view.View
    private lateinit var tabOriginal: TextView
    private lateinit var tabTranslated: TextView
    private lateinit var tvNoImage: TextView
    private lateinit var tvResult: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var dividerOriginal: android.view.View
    private lateinit var pbLoading: ProgressBar
    private lateinit var btnCopy: ImageButton
    private lateinit var btnCopyTop: ImageButton
    private lateinit var btnSaveImage: ImageButton
    private lateinit var btnRetry: Button

    private var lastTranslated: String? = null
    private var lastBitmap: Bitmap? = null
    private var pendingCameraUri: Uri? = null
    private var overlayReady = false
    private var wantsTranslatedView = false

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadAndHandle(uri)
        }

    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) pendingCameraUri?.let { loadAndHandle(it) }
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCamera() else
                Toast.makeText(this, getString(R.string.camera_permission_needed), Toast.LENGTH_LONG).show()
        }

    private val storagePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) saveTranslatedImage() else
                Toast.makeText(this, getString(R.string.image_save_failed_toast), Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_translate)

        ivPreview = findViewById(R.id.ivPreview)
        overlayView = findViewById(R.id.overlayView)
        pbOverlayLoading = findViewById(R.id.pbOverlayLoading)
        tabToggle = findViewById(R.id.tabToggle)
        tabOriginal = findViewById(R.id.tabOriginal)
        tabTranslated = findViewById(R.id.tabTranslated)
        tvNoImage = findViewById(R.id.tvNoImage)
        tvResult = findViewById(R.id.tvResult)
        tvOriginal = findViewById(R.id.tvOriginal)
        dividerOriginal = findViewById(R.id.dividerOriginal)
        pbLoading = findViewById(R.id.pbLoading)
        btnCopy = findViewById(R.id.btnCopy)
        btnCopyTop = findViewById(R.id.btnCopyTop)
        btnSaveImage = findViewById(R.id.btnSaveImage)
        btnRetry = findViewById(R.id.btnRetry)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnPickGallery).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        findViewById<android.view.View>(R.id.btnTakePhoto).setOnClickListener {
            checkCameraPermissionAndLaunch()
        }
        btnCopy.setOnClickListener { copyResult() }
        btnCopyTop.setOnClickListener { copyResult() }
        btnSaveImage.setOnClickListener { checkStoragePermissionAndSave() }
        btnRetry.setOnClickListener { lastBitmap?.let { recognizeAndTranslate(it) } }

        overlayView.onBoxTapped = { text ->
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
            Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
        }

        tabOriginal.setOnClickListener { selectTab(translated = false) }
        tabTranslated.setOnClickListener { selectTab(translated = true) }
    }

    private fun selectTab(translated: Boolean) {
        wantsTranslatedView = translated
        tabOriginal.setBackgroundResource(if (!translated) R.drawable.bg_button_blue else 0)
        tabOriginal.setTextColor(if (!translated) getColor(R.color.white) else getColor(R.color.text_secondary))
        tabTranslated.setBackgroundResource(if (translated) R.drawable.bg_button_blue else 0)
        tabTranslated.setTextColor(if (translated) getColor(R.color.white) else getColor(R.color.text_secondary))

        if (translated) {
            if (overlayReady) {
                overlayView.visibility = android.view.View.VISIBLE
                pbOverlayLoading.visibility = android.view.View.GONE
            } else {
                overlayView.visibility = android.view.View.GONE
                pbOverlayLoading.visibility = android.view.View.VISIBLE
            }
        } else {
            overlayView.visibility = android.view.View.GONE
            pbOverlayLoading.visibility = android.view.View.GONE
        }
    }

    private fun checkCameraPermissionAndLaunch() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) launchCamera() else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "camera_images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhotoLauncher.launch(uri)
    }

    private fun decodeSampledBitmap(uri: Uri): Bitmap? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }

            var sample = 1
            val w = boundsOptions.outWidth
            val h = boundsOptions.outHeight
            while (w / sample > MAX_DIMENSION || h / sample > MAX_DIMENSION) {
                sample *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun loadAndHandle(uri: Uri) {
        val bitmap = decodeSampledBitmap(uri)
        if (bitmap == null) {
            Toast.makeText(this, getString(R.string.no_text_found), Toast.LENGTH_SHORT).show()
            return
        }
        lastBitmap = bitmap
        overlayReady = false
        overlayView.boxes = emptyList()

        ivPreview.setImageBitmap(bitmap)
        tvNoImage.visibility = android.view.View.GONE
        btnCopy.visibility = android.view.View.GONE
        btnCopyTop.visibility = android.view.View.GONE
        btnSaveImage.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE
        tabToggle.visibility = android.view.View.VISIBLE
        selectTab(translated = false)

        recognizeAndTranslate(bitmap)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        btnCopy.visibility = android.view.View.GONE
        btnCopyTop.visibility = android.view.View.GONE
        btnSaveImage.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE
        tvOriginal.visibility = android.view.View.GONE
        dividerOriginal.visibility = android.view.View.GONE
        pbLoading.visibility = android.view.View.VISIBLE
        tvResult.text = getString(R.string.recognizing_text)
        overlayReady = false

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                when {
                    recognized.isEmpty() -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.no_text_found)
                    }
                    !looksLikeTranslatableEnglish(recognized) -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.lens_not_clear_hint)
                    }
                    else -> {
                        translateText(recognized)
                        buildOverlay(visionText, bitmap.width, bitmap.height)
                    }
                }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.translate_failed)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    /** OCR-এ পাওয়া লেখা আসলেই অনুবাদযোগ্য ইংরেজি বাক্য/বাক্যাংশ কিনা যাচাই করে। */
    private fun looksLikeTranslatableEnglish(text: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 4) return false

        val latinCount = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
        val latinRatio = latinCount.toFloat() / letters.length
        if (latinRatio < 0.7f) return false

        val words = text.split(Regex("\\s+")).filter { it.any(Char::isLetter) }
        val hasDecentWord = words.any { it.filter(Char::isLetter).length >= 3 }
        return words.size >= 2 || hasDecentWord
    }

    private fun translateText(english: String) {
        tvResult.text = getString(R.string.translating)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        pbLoading.visibility = android.view.View.GONE
                        lastTranslated = translated
                        tvResult.text = translated
                        tvOriginal.text = english
                        tvOriginal.visibility = android.view.View.VISIBLE
                        dividerOriginal.visibility = android.view.View.VISIBLE
                        btnCopy.visibility = android.view.View.VISIBLE
                        btnCopyTop.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "image", english, translated)
                    }
                    .addOnFailureListener {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.translate_failed)
                        btnRetry.visibility = android.view.View.VISIBLE
                    }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.lens_download_error_hint)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    /**
     * প্রতিটা লাইন আলাদাভাবে অনুবাদ করে, সেই লাইনের ঠিক জায়গায় (bounding box) বসানোর
     * জন্য প্রস্তুত করে -- Google Lens-এর "Translated" ভিউয়ের মতো ছবির উপরেই বাংলা
     * দেখানোর জন্য। শুধু বৈধ ইংরেজি লাইনগুলোই অনুবাদ হয়।
     */
    private fun buildOverlay(visionText: Text, bitmapWidth: Int, bitmapHeight: Int) {
        val eligibleLines = mutableListOf<Pair<RectF, String>>()
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                if (looksLikeTranslatableEnglish(line.text)) {
                    eligibleLines.add(RectF(box) to line.text)
                }
            }
        }

        if (eligibleLines.isEmpty()) {
            overlayReady = true
            overlayView.boxes = emptyList()
            return
        }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)
        overlayView.sourceWidth = bitmapWidth
        overlayView.sourceHeight = bitmapHeight

        translator.downloadModelIfNeeded().addOnSuccessListener {
            val results = arrayOfNulls<TranslationOverlayView.Box>(eligibleLines.size)
            var remaining = eligibleLines.size

            eligibleLines.forEachIndexed { index, (rect, text) ->
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        results[index] = TranslationOverlayView.Box(rect, translated)
                        remaining--
                        if (remaining == 0) finishOverlay(results)
                    }
                    .addOnFailureListener {
                        remaining--
                        if (remaining == 0) finishOverlay(results)
                    }
            }
        }.addOnFailureListener {
            overlayReady = true
        }
    }

    private fun finishOverlay(results: Array<TranslationOverlayView.Box?>) {
        overlayView.boxes = results.filterNotNull()
        overlayReady = true
        if (overlayView.boxes.isNotEmpty()) {
            btnSaveImage.visibility = android.view.View.VISIBLE
        }
        if (wantsTranslatedView) {
            overlayView.visibility = android.view.View.VISIBLE
            pbOverlayLoading.visibility = android.view.View.GONE
        }
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }

    private fun checkStoragePermissionAndSave() {
        // Android 10+ (API 29+) স্কোপড স্টোরেজে MediaStore দিয়ে সেভ করতে আলাদা
        // পারমিশন লাগে না -- শুধু পুরনো ভার্সনে (API 28-) দরকার
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }
        saveTranslatedImage()
    }

    /**
     * মূল ছবির উপরেই অনুবাদ করা বাংলা লেখাগুলো (ঠিক যেই বাক্সে OCR পেয়েছিল) এঁকে
     * একটা নতুন বিটম্যাপ বানিয়ে গ্যালারিতে সেভ করে -- এতে ছবিটার ইংরেজি লেখা
     * সত্যিই বাংলা হয়ে যাওয়া একটা নতুন ছবি হিসেবে থেকে যায়, শেয়ারও করা যায়।
     */
    private fun saveTranslatedImage() {
        val original = lastBitmap
        val boxes = overlayView.boxes
        if (original == null || boxes.isEmpty()) {
            Toast.makeText(this, getString(R.string.image_save_failed_toast), Toast.LENGTH_SHORT).show()
            return
        }

        val output = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E01F7A6C")
            style = Paint.Style.FILL
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.LEFT
        }

        for (box in boxes) {
            val r = box.rect
            if (r.right <= r.left || r.bottom <= r.top) continue
            canvas.drawRoundRect(r, 6f, 6f, bgPaint)

            val boxHeight = r.bottom - r.top
            var textSize = (boxHeight * 0.58f).coerceIn(16f, 90f)
            textPaint.textSize = textSize
            var tw = textPaint.measureText(box.text)
            val maxWidth = (r.right - r.left) - 10f
            while (tw > maxWidth && textSize > 10f) {
                textSize -= 1f
                textPaint.textSize = textSize
                tw = textPaint.measureText(box.text)
            }
            val textY = r.top + (boxHeight + textSize * 0.7f) / 2f
            canvas.drawText(box.text, r.left + 5f, textY, textPaint)
        }

        val saved = try {
            writeBitmapToGallery(output)
        } catch (_: Exception) {
            false
        }

        Toast.makeText(
            this,
            getString(if (saved) R.string.image_saved_toast else R.string.image_save_failed_toast),
            Toast.LENGTH_LONG
        ).show()
    }

    private fun writeBitmapToGallery(bitmap: Bitmap): Boolean {
        val filename = "HeyOrthi_${System.currentTimeMillis()}.jpg"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Hey Orthi")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            } ?: return false
            return true
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val appDir = File(picturesDir, "Hey Orthi").apply { mkdirs() }
            val file = File(appDir, filename)
            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            // গ্যালারি অ্যাপ যেন সাথে সাথে নতুন ছবিটা দেখতে পায়
            android.media.MediaScannerConnection.scanFile(
                this, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null
            )
            return true
        }
    }
}
