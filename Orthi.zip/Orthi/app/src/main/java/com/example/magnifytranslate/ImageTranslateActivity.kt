package com.example.magnifytranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

/** Gallery থেকে বেছে নেওয়া বা ক্যামেরায় তোলা ছবি থেকে ইংরেজি লেখা বের করে বাংলায় অনুবাদ করার স্ক্রিন। */
class ImageTranslateActivity : AppCompatActivity() {

    companion object {
        // ক্যামেরার ছবি সাধারণত ৩০০০-৪০০০+ পিক্সেল হয় -- ফুল সাইজে লোড করলে
        // মেমোরি সমস্যা/ধীরগতি হয়। OCR-এর জন্য এই সাইজই যথেষ্ট, বরং বেশি নির্ভুল।
        private const val MAX_DIMENSION = 1600
    }

    private lateinit var ivPreview: ImageView
    private lateinit var tvNoImage: TextView
    private lateinit var tvResult: TextView
    private lateinit var pbLoading: ProgressBar
    private lateinit var btnCopy: ImageButton
    private lateinit var btnRetry: Button
    private var lastTranslated: String? = null
    private var lastBitmap: Bitmap? = null
    private var pendingCameraUri: Uri? = null

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadAndHandle(uri)
        }

    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) pendingCameraUri?.let { loadAndHandle(it) }
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCamera() else
                Toast.makeText(this, getString(R.string.camera_permission_needed), Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_translate)

        ivPreview = findViewById(R.id.ivPreview)
        tvNoImage = findViewById(R.id.tvNoImage)
        tvResult = findViewById(R.id.tvResult)
        pbLoading = findViewById(R.id.pbLoading)
        btnCopy = findViewById(R.id.btnCopy)
        btnRetry = findViewById(R.id.btnRetry)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnPickGallery).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        findViewById<android.view.View>(R.id.btnTakePhoto).setOnClickListener {
            checkCameraPermissionAndLaunch()
        }
        btnCopy.setOnClickListener { copyResult() }
        btnRetry.setOnClickListener { lastBitmap?.let { recognizeAndTranslate(it) } }

        ivPreview.visibility = android.view.View.GONE
    }

    private fun checkCameraPermissionAndLaunch() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) launchCamera() else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "camera_images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhotoLauncher.launch(uri)
    }

    /** ছবি Uri থেকে সরাসরি ফুল-সাইজ ডিকোড না করে, প্রথমে আসল মাপ জেনে যথাযথভাবে ছোট করে লোড করে। */
    private fun decodeSampledBitmap(uri: Uri): Bitmap? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }

            var sample = 1
            var w = boundsOptions.outWidth
            var h = boundsOptions.outHeight
            while (w / sample > MAX_DIMENSION || h / sample > MAX_DIMENSION) {
                sample *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun loadAndHandle(uri: Uri) {
        val bitmap = decodeSampledBitmap(uri)
        if (bitmap == null) {
            Toast.makeText(this, getString(R.string.no_text_found), Toast.LENGTH_SHORT).show()
            return
        }
        lastBitmap = bitmap

        ivPreview.setImageBitmap(bitmap)
        ivPreview.visibility = android.view.View.VISIBLE
        tvNoImage.visibility = android.view.View.GONE
        btnCopy.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE

        recognizeAndTranslate(bitmap)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        btnCopy.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE
        pbLoading.visibility = android.view.View.VISIBLE
        tvResult.text = getString(R.string.recognizing_text)

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                when {
                    recognized.isEmpty() -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.no_text_found)
                    }
                    !looksLikeTranslatableEnglish(recognized) -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.lens_not_clear_hint)
                    }
                    else -> translateText(recognized)
                }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.translate_failed)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    /** OCR-এ পাওয়া লেখা আসলেই অনুবাদযোগ্য ইংরেজি বাক্য/বাক্যাংশ কিনা যাচাই করে। */
    private fun looksLikeTranslatableEnglish(text: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 4) return false

        val latinCount = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
        val latinRatio = latinCount.toFloat() / letters.length
        if (latinRatio < 0.7f) return false

        val words = text.split(Regex("\\s+")).filter { it.any(Char::isLetter) }
        val hasDecentWord = words.any { it.filter(Char::isLetter).length >= 3 }
        return words.size >= 2 || hasDecentWord
    }

    private fun translateText(english: String) {
        tvResult.text = getString(R.string.translating)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        pbLoading.visibility = android.view.View.GONE
                        lastTranslated = translated
                        tvResult.text = translated
                        btnCopy.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "image", english, translated)
                    }
                    .addOnFailureListener {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.translate_failed)
                        btnRetry.visibility = android.view.View.VISIBLE
                    }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.lens_download_error_hint)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
