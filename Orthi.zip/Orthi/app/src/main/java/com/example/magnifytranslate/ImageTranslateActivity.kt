package com.example.magnifytranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

/**
 * Gallery/ক্যামেরার ছবি থেকে ইংরেজি লেখা বের করে বাংলায় অনুবাদ করার স্ক্রিন।
 * Google Lens-এর মতো ছবির উপরেই সরাসরি বাংলা বসিয়ে দেখানোর "Translated" ভিউ আছে
 * (Original/Translated টগল), সাথে নিচে সম্পূর্ণ লেখা পড়ার মতো করেও দেখানো থাকে,
 * যা Lens-এ নেই -- কপি করার আর ইতিহাসে সেভ করার সুবিধার জন্য।
 */
class ImageTranslateActivity : AppCompatActivity() {

    companion object {
        private const val MAX_DIMENSION = 1600
    }

    private lateinit var ivPreview: ImageView
    private lateinit var overlayView: TranslationOverlayView
    private lateinit var pbOverlayLoading: ProgressBar
    private lateinit var tabToggle: android.view.View
    private lateinit var tabOriginal: TextView
    private lateinit var tabTranslated: TextView
    private lateinit var tvNoImage: TextView
    private lateinit var tvResult: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var dividerOriginal: android.view.View
    private lateinit var pbLoading: ProgressBar
    private lateinit var btnCopy: ImageButton
    private lateinit var btnRetry: Button

    private var lastTranslated: String? = null
    private var lastBitmap: Bitmap? = null
    private var pendingCameraUri: Uri? = null
    private var overlayReady = false
    private var wantsTranslatedView = false

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) loadAndHandle(uri)
        }

    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) pendingCameraUri?.let { loadAndHandle(it) }
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCamera() else
                Toast.makeText(this, getString(R.string.camera_permission_needed), Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_translate)

        ivPreview = findViewById(R.id.ivPreview)
        overlayView = findViewById(R.id.overlayView)
        pbOverlayLoading = findViewById(R.id.pbOverlayLoading)
        tabToggle = findViewById(R.id.tabToggle)
        tabOriginal = findViewById(R.id.tabOriginal)
        tabTranslated = findViewById(R.id.tabTranslated)
        tvNoImage = findViewById(R.id.tvNoImage)
        tvResult = findViewById(R.id.tvResult)
        tvOriginal = findViewById(R.id.tvOriginal)
        dividerOriginal = findViewById(R.id.dividerOriginal)
        pbLoading = findViewById(R.id.pbLoading)
        btnCopy = findViewById(R.id.btnCopy)
        btnRetry = findViewById(R.id.btnRetry)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnPickGallery).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        findViewById<android.view.View>(R.id.btnTakePhoto).setOnClickListener {
            checkCameraPermissionAndLaunch()
        }
        btnCopy.setOnClickListener { copyResult() }
        btnRetry.setOnClickListener { lastBitmap?.let { recognizeAndTranslate(it) } }

        tabOriginal.setOnClickListener { selectTab(translated = false) }
        tabTranslated.setOnClickListener { selectTab(translated = true) }
    }

    private fun selectTab(translated: Boolean) {
        wantsTranslatedView = translated
        tabOriginal.setBackgroundResource(if (!translated) R.drawable.bg_button_blue else 0)
        tabOriginal.setTextColor(if (!translated) getColor(R.color.white) else getColor(R.color.text_secondary))
        tabTranslated.setBackgroundResource(if (translated) R.drawable.bg_button_blue else 0)
        tabTranslated.setTextColor(if (translated) getColor(R.color.white) else getColor(R.color.text_secondary))

        if (translated) {
            if (overlayReady) {
                overlayView.visibility = android.view.View.VISIBLE
                pbOverlayLoading.visibility = android.view.View.GONE
            } else {
                overlayView.visibility = android.view.View.GONE
                pbOverlayLoading.visibility = android.view.View.VISIBLE
            }
        } else {
            overlayView.visibility = android.view.View.GONE
            pbOverlayLoading.visibility = android.view.View.GONE
        }
    }

    private fun checkCameraPermissionAndLaunch() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) launchCamera() else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "camera_images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhotoLauncher.launch(uri)
    }

    private fun decodeSampledBitmap(uri: Uri): Bitmap? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, boundsOptions)
            }

            var sample = 1
            val w = boundsOptions.outWidth
            val h = boundsOptions.outHeight
            while (w / sample > MAX_DIMENSION || h / sample > MAX_DIMENSION) {
                sample *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sample }
            contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun loadAndHandle(uri: Uri) {
        val bitmap = decodeSampledBitmap(uri)
        if (bitmap == null) {
            Toast.makeText(this, getString(R.string.no_text_found), Toast.LENGTH_SHORT).show()
            return
        }
        lastBitmap = bitmap
        overlayReady = false
        overlayView.boxes = emptyList()

        ivPreview.setImageBitmap(bitmap)
        tvNoImage.visibility = android.view.View.GONE
        btnCopy.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE
        tabToggle.visibility = android.view.View.VISIBLE
        selectTab(translated = false)

        recognizeAndTranslate(bitmap)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        btnCopy.visibility = android.view.View.GONE
        btnRetry.visibility = android.view.View.GONE
        tvOriginal.visibility = android.view.View.GONE
        dividerOriginal.visibility = android.view.View.GONE
        pbLoading.visibility = android.view.View.VISIBLE
        tvResult.text = getString(R.string.recognizing_text)
        overlayReady = false

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                when {
                    recognized.isEmpty() -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.no_text_found)
                    }
                    !looksLikeTranslatableEnglish(recognized) -> {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.lens_not_clear_hint)
                    }
                    else -> {
                        translateText(recognized)
                        buildOverlay(visionText, bitmap.width, bitmap.height)
                    }
                }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.translate_failed)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    /** OCR-এ পাওয়া লেখা আসলেই অনুবাদযোগ্য ইংরেজি বাক্য/বাক্যাংশ কিনা যাচাই করে। */
    private fun looksLikeTranslatableEnglish(text: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 4) return false

        val latinCount = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
        val latinRatio = latinCount.toFloat() / letters.length
        if (latinRatio < 0.7f) return false

        val words = text.split(Regex("\\s+")).filter { it.any(Char::isLetter) }
        val hasDecentWord = words.any { it.filter(Char::isLetter).length >= 3 }
        return words.size >= 2 || hasDecentWord
    }

    private fun translateText(english: String) {
        tvResult.text = getString(R.string.translating)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        pbLoading.visibility = android.view.View.GONE
                        lastTranslated = translated
                        tvResult.text = translated
                        tvOriginal.text = english
                        tvOriginal.visibility = android.view.View.VISIBLE
                        dividerOriginal.visibility = android.view.View.VISIBLE
                        btnCopy.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "image", english, translated)
                    }
                    .addOnFailureListener {
                        pbLoading.visibility = android.view.View.GONE
                        tvResult.text = getString(R.string.translate_failed)
                        btnRetry.visibility = android.view.View.VISIBLE
                    }
            }
            .addOnFailureListener {
                pbLoading.visibility = android.view.View.GONE
                tvResult.text = getString(R.string.lens_download_error_hint)
                btnRetry.visibility = android.view.View.VISIBLE
            }
    }

    /**
     * প্রতিটা লাইন আলাদাভাবে অনুবাদ করে, সেই লাইনের ঠিক জায়গায় (bounding box) বসানোর
     * জন্য প্রস্তুত করে -- Google Lens-এর "Translated" ভিউয়ের মতো ছবির উপরেই বাংলা
     * দেখানোর জন্য। শুধু বৈধ ইংরেজি লাইনগুলোই অনুবাদ হয়।
     */
    private fun buildOverlay(visionText: Text, bitmapWidth: Int, bitmapHeight: Int) {
        val eligibleLines = mutableListOf<Pair<RectF, String>>()
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                if (looksLikeTranslatableEnglish(line.text)) {
                    eligibleLines.add(RectF(box) to line.text)
                }
            }
        }

        if (eligibleLines.isEmpty()) {
            overlayReady = true
            overlayView.boxes = emptyList()
            return
        }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)
        overlayView.sourceWidth = bitmapWidth
        overlayView.sourceHeight = bitmapHeight

        translator.downloadModelIfNeeded().addOnSuccessListener {
            val results = arrayOfNulls<TranslationOverlayView.Box>(eligibleLines.size)
            var remaining = eligibleLines.size

            eligibleLines.forEachIndexed { index, (rect, text) ->
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        results[index] = TranslationOverlayView.Box(rect, translated)
                        remaining--
                        if (remaining == 0) finishOverlay(results)
                    }
                    .addOnFailureListener {
                        remaining--
                        if (remaining == 0) finishOverlay(results)
                    }
            }
        }.addOnFailureListener {
            overlayReady = true
        }
    }

    private fun finishOverlay(results: Array<TranslationOverlayView.Box?>) {
        overlayView.boxes = results.filterNotNull()
        overlayReady = true
        if (wantsTranslatedView) {
            overlayView.visibility = android.view.View.VISIBLE
            pbOverlayLoading.visibility = android.view.View.GONE
        }
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
