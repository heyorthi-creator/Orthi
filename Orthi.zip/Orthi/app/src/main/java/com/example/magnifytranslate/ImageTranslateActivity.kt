package com.example.magnifytranslate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

/** Gallery থেকে বেছে নেওয়া বা ক্যামেরায় তোলা ছবি থেকে ইংরেজি লেখা বের করে বাংলায় অনুবাদ করার স্ক্রিন। */
class ImageTranslateActivity : AppCompatActivity() {

    private lateinit var ivPreview: ImageView
    private lateinit var tvNoImage: TextView
    private lateinit var tvResult: TextView
    private lateinit var btnCopy: ImageButton
    private var lastTranslated: String? = null
    private var pendingCameraUri: Uri? = null

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) handleImage(uri)
        }

    private val takePhotoLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
            if (success) pendingCameraUri?.let { handleImage(it) }
        }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) launchCamera() else
                Toast.makeText(this, getString(R.string.camera_permission_needed), Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeManager.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_translate)

        ivPreview = findViewById(R.id.ivPreview)
        tvNoImage = findViewById(R.id.tvNoImage)
        tvResult = findViewById(R.id.tvResult)
        btnCopy = findViewById(R.id.btnCopy)

        findViewById<android.view.View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.view.View>(R.id.btnPickGallery).setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        findViewById<android.view.View>(R.id.btnTakePhoto).setOnClickListener {
            checkCameraPermissionAndLaunch()
        }
        btnCopy.setOnClickListener { copyResult() }

        ivPreview.visibility = android.view.View.GONE
    }

    private fun checkCameraPermissionAndLaunch() {
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) launchCamera() else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "camera_images").apply { mkdirs() }
        val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        pendingCameraUri = uri
        takePhotoLauncher.launch(uri)
    }

    private fun handleImage(uri: Uri) {
        val bitmap = try {
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null } ?: run {
            Toast.makeText(this, getString(R.string.no_text_found), Toast.LENGTH_SHORT).show()
            return
        }

        ivPreview.setImageBitmap(bitmap)
        ivPreview.visibility = android.view.View.VISIBLE
        tvNoImage.visibility = android.view.View.GONE
        btnCopy.visibility = android.view.View.GONE
        tvResult.text = getString(R.string.recognizing_text)

        recognizeAndTranslate(bitmap)
    }

    private fun recognizeAndTranslate(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val recognized = visionText.text.trim()
                if (recognized.isEmpty()) {
                    tvResult.text = getString(R.string.no_text_found)
                } else {
                    translateText(recognized)
                }
            }
            .addOnFailureListener {
                tvResult.text = getString(R.string.no_text_found)
            }
    }

    private fun translateText(english: String) {
        tvResult.text = getString(R.string.translating)
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.BENGALI)
            .build()
        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(english)
                    .addOnSuccessListener { translated ->
                        lastTranslated = translated
                        tvResult.text = translated
                        btnCopy.visibility = android.view.View.VISIBLE
                        TranslationHistoryStore.add(this, "image", english, translated)
                    }
                    .addOnFailureListener { tvResult.text = getString(R.string.no_text_found) }
            }
            .addOnFailureListener { tvResult.text = getString(R.string.no_text_found) }
    }

    private fun copyResult() {
        val text = lastTranslated ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Hey Orthi", text))
        Toast.makeText(this, getString(R.string.copied_toast), Toast.LENGTH_SHORT).show()
    }
}
