package com.example.magnifytranslate

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.content.ContextCompat

/**
 * Google Assistant-এর মতো একটা ছোট্ট "শুনছি" (listening) ভিজ্যুয়াল ইন্ডিকেটর।
 * তিনটা অবস্থা দেখাতে পারে:
 *  - LISTENING     : "Hey Orthi" শোনার অপেক্ষায় -- ধীরে স্পন্দিত (breathing) সবুজ বৃত্ত,
 *                     কণ্ঠস্বরের ভলিউম অনুযায়ী বৃত্তগুলো একটু বড়/ছোট হয়
 *  - HEARD_WAKE     : wake word পাওয়া গেছে, এখন কমান্ডের অপেক্ষায় -- দ্রুত স্পন্দিত অ্যাম্বার বৃত্ত
 *  - PROCESSING     : অনুবাদ হচ্ছে -- ঘোরা রিং (spinner)
 *
 * এই ভিউটা সম্পূর্ণ কোড দিয়ে আঁকা (Canvas), তাই আলাদা কোনো ইমেজ/আইকন লাগে না।
 */
class VoiceListeningIndicatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { LISTENING, HEARD_WAKE, PROCESSING }

    private var state: State = State.LISTENING
    private var breathPhase = 0f   // ০..১, ধীর "শ্বাস নেওয়ার" মতো লুপ
    private var spinPhase = 0f     // ০..৩৬০, PROCESSING স্পিনার ঘোরানোর জন্য
    private var micLevel = 0f      // ০..১, RMS থেকে আসা কণ্ঠস্বরের স্মুথ করা মাত্রা

    private val colorTeal = ContextCompat.getColor(context, R.color.teal)
    private val colorTealDark = ContextCompat.getColor(context, R.color.teal_dark)
    private val colorAmber = ContextCompat.getColor(context, R.color.amber)
    private val colorAmberDark = ContextCompat.getColor(context, R.color.amber_dark)
    private val colorWhite = ContextCompat.getColor(context, R.color.white)

    private val breathAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1300
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            breathPhase = it.animatedValue as Float
            invalidate()
        }
    }

    private val spinAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 900
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            spinPhase = it.animatedValue as Float
            invalidate()
        }
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val micPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }

    init {
        breathAnimator.start()
    }

    fun setState(newState: State) {
        if (state == newState) return
        state = newState
        if (newState == State.PROCESSING) {
            if (!spinAnimator.isStarted) spinAnimator.start()
        } else {
            spinAnimator.cancel()
        }
        invalidate()
    }

    /** ০..১ পরিসরে মাইক্রোফোনের ভলিউম লেভেল সেট করে (নিজে থেকেই স্মুথ হয়, ঝাঁকুনি কমায়) */
    fun setMicLevel(rawLevel: Float) {
        val clamped = rawLevel.coerceIn(0f, 1f)
        micLevel = micLevel * 0.7f + clamped * 0.3f
        invalidate()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        breathAnimator.cancel()
        spinAnimator.cancel()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = minOf(width, height) / 2f * 0.34f

        val coreColor: Int
        val ringColor: Int
        when (state) {
            State.LISTENING -> { coreColor = colorTeal; ringColor = colorTeal }
            State.HEARD_WAKE -> { coreColor = colorAmberDark; ringColor = colorAmber }
            State.PROCESSING -> { coreColor = colorTealDark; ringColor = colorTeal }
        }

        if (state == State.PROCESSING) {
            // ঘোরা রিং -- অনুবাদ প্রসেসিং বোঝাতে
            ringPaint.color = ringColor
            ringPaint.strokeWidth = 6f
            ringPaint.alpha = 255
            val sweepRadius = baseRadius * 1.7f
            canvas.drawArc(
                cx - sweepRadius, cy - sweepRadius, cx + sweepRadius, cy + sweepRadius,
                spinPhase, 110f, false, ringPaint
            )
        } else {
            // ধীরে স্পন্দিত (breathing) বৃত্ত + কণ্ঠস্বরের মাত্রা অনুযায়ী বাড়া/কমা
            val pulseStrength = if (state == State.HEARD_WAKE) 1.5f else 1f
            for (i in 2 downTo 0) {
                val ringProgress = (breathPhase + i * 0.3f) % 1f
                val radius = baseRadius +
                    (ringProgress * baseRadius * 1.8f * pulseStrength) +
                    (micLevel * baseRadius * 0.9f)
                val alpha = ((1f - ringProgress) * 90).toInt().coerceIn(0, 90)
                ringPaint.color = ringColor
                ringPaint.strokeWidth = 4f
                ringPaint.alpha = alpha
                canvas.drawCircle(cx, cy, radius, ringPaint)
            }
        }

        // কেন্দ্রের মূল বৃত্ত
        corePaint.color = coreColor
        corePaint.alpha = 255
        canvas.drawCircle(cx, cy, baseRadius, corePaint)

        // মাইক আইকন
        micPaint.color = colorWhite
        micPaint.textSize = baseRadius * 0.95f
        canvas.drawText("🎙", cx, cy + baseRadius * 0.35f, micPaint)
    }
}
