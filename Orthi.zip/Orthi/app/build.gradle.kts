plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.magnifytranslate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.magnifytranslate"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    // একটা স্থায়ী (fixed) সাইনিং কী -- এটা না থাকলে প্রতিবার CI বিল্ডে
    // এলোমেলো নতুন কী তৈরি হয়ে যেত, তাই আপডেটের সময় আগের অ্যাপ uninstall করা লাগত।
    signingConfigs {
        create("orthi") {
            storeFile = file("orthi-release.keystore")
            storePassword = "orthi123456"
            keyAlias = "orthi"
            keyPassword = "orthi123456"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("orthi")
        }
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("orthi")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.cardview:cardview:1.0.0")

    // On-device OCR (English text recognition)
    implementation("com.google.mlkit:text-recognition:16.0.0")

    // On-device translation (English -> Bengali)
    implementation("com.google.mlkit:translate:17.0.3")
}
